-- Ejecutar dentro de la base de datos lsc_conecta2 existente.
-- No elimina ni reemplaza las tablas originales.
USE lsc_conecta2;
CREATE TABLE IF NOT EXISTS c2_progreso_usuario (
  id_usuario INT NOT NULL PRIMARY KEY,
  payload LONGTEXT NOT NULL,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_c2_progreso_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS c2_resultado_evaluacion (
  id_resultado BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  modulo VARCHAR(120) NOT NULL,
  puntaje TINYINT UNSIGNED NOT NULL,
  aciertos SMALLINT UNSIGNED NOT NULL,
  total_preguntas SMALLINT UNSIGNED NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_c2_resultado_usuario (id_usuario),
  CONSTRAINT fk_c2_resultado_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
