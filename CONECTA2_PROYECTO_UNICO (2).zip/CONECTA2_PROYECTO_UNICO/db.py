import os
from pathlib import Path
import mysql.connector
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / '.env')

def get_db_connection():
    required = ('MYSQL_HOST', 'MYSQL_DATABASE', 'MYSQL_USER')
    missing = [key for key in required if not os.environ.get(key)]
    if missing:
        raise ValueError('Faltan variables de entorno: ' + ', '.join(missing))
    return mysql.connector.connect(
        host=os.environ['MYSQL_HOST'],
        port=int(os.environ.get('MYSQL_PORT', '3307')),
        database=os.environ['MYSQL_DATABASE'],
        user=os.environ['MYSQL_USER'],
        password=os.environ.get('MYSQL_PASSWORD', ''),
        connection_timeout=5,
        charset='utf8mb4',
        use_unicode=True,
    )
