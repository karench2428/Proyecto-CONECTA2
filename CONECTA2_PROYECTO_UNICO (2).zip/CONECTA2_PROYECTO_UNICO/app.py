import json, logging, os, secrets
from datetime import timedelta
from pathlib import Path

import mysql.connector
from flask import Flask, jsonify, request, send_from_directory, session
from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db_connection

ROOT = Path(__file__).resolve().parent
app = Flask(__name__, static_folder='static', static_url_path='/static')
secret_file = ROOT / '.flask_secret_key'
secret = os.environ.get('FLASK_SECRET_KEY')
if not secret:
    try: secret = secret_file.read_text(encoding='utf-8').strip()
    except FileNotFoundError:
        secret = secrets.token_hex(32)
        secret_file.write_text(secret, encoding='utf-8')
app.config.update(SECRET_KEY=secret, SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE='Lax', PERMANENT_SESSION_LIFETIME=timedelta(days=30))
logging.basicConfig(level=logging.INFO)

@app.get('/')
def home():
    return send_from_directory(ROOT, 'index.html')

@app.get('/api/health')
def health():
    try:
        con = get_db_connection()
        con.close()
        return jsonify(ok=True, database='connected')
    except Exception as exc:
        app.logger.warning('Health check failed: %s', exc)
        return jsonify(ok=False, database='disconnected', message='Revisa la configuración de MySQL en .env.'), 503

def api_error(message, status=400):
    return jsonify(ok=False, error=message), status

@app.post('/api/register')
def register():
    data = request.get_json(silent=True) or {}
    names = str(data.get('names', '')).strip()
    surnames = str(data.get('surnames', '')).strip()
    email = str(data.get('email', '')).strip().lower()
    password = data.get('password', '')
    if not names or not surnames or not email or not isinstance(password, str):
        return api_error('Completa nombres, apellidos, correo y contraseña.')
    if '@' not in email or len(email) > 120:
        return api_error('Escribe un correo electrónico válido.')
    if len(password) < 8:
        return api_error('La contraseña debe tener al menos 8 caracteres.')
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            cur.execute("SELECT id_rol FROM rol WHERE LOWER(nombre)='estudiante' ORDER BY id_rol LIMIT 1")
            role = cur.fetchone()
            if not role:
                cur.execute('SELECT id_rol FROM rol ORDER BY id_rol LIMIT 1')
                role = cur.fetchone()
            if not role:
                return api_error('No existen roles en la base de datos. Ejecuta primero el SQL de CONECTA2.', 503)
            cur.execute('SELECT id_usuario FROM usuario WHERE LOWER(correo)=%s LIMIT 1', (email,))
            if cur.fetchone(): return api_error('Ese correo ya está registrado.', 409)
            cur.execute('INSERT INTO usuario (id_rol,nombres,apellidos,correo,contrasena,estado) VALUES (%s,%s,%s,%s,%s,\'Activo\')',
                        (role['id_rol'], names, surnames, email, generate_password_hash(password)))
            user_id = cur.lastrowid
        con.commit()
        session.clear(); session.permanent = True
        session.update(user_id=user_id, email=email, name=names, role='Estudiante')
        return jsonify(ok=True, message='Cuenta creada.', user={'id': user_id, 'name': names, 'email': email, 'role': 'Estudiante'}), 201
    except mysql.connector.Error:
        app.logger.exception('Registration failed')
        if con: con.rollback()
        return api_error('No fue posible crear la cuenta. Comprueba la conexión y las tablas de MySQL.', 503)
    finally:
        if con: con.close()

@app.post('/api/login')
def login():
    data = request.get_json(silent=True)
    if not isinstance(data, dict): return api_error('La solicitud debe contener JSON.', 415)
    email = data.get('email'); password = data.get('password')
    if not isinstance(email, str) or not isinstance(password, str) or not email.strip() or not password:
        return api_error('Ingresa tu correo y contraseña.')
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            cur.execute('''SELECT u.id_usuario,u.nombres,u.apellidos,u.correo,u.contrasena,u.estado,r.nombre AS rol
                           FROM usuario u JOIN rol r ON r.id_rol=u.id_rol WHERE LOWER(u.correo)=%s LIMIT 1''', (email.strip().lower(),))
            user = cur.fetchone()
        if not user or user['estado'] != 'Activo' or not check_password_hash(user['contrasena'], password):
            return api_error('Correo o contraseña incorrectos.', 401)
        session.clear(); session.permanent = True
        session.update(user_id=user['id_usuario'], email=user['correo'], name=user['nombres'], role=user['rol'])
        return jsonify(ok=True, message='Sesión iniciada.', user={'id': user['id_usuario'], 'name': user['nombres'], 'surnames': user['apellidos'], 'email': user['correo'], 'role': user['rol']})
    except (mysql.connector.Error, ValueError):
        app.logger.exception('Login database error')
        return api_error('El inicio de sesión no está disponible. Revisa MySQL y el archivo .env.', 503)
    finally:
        if con: con.close()

@app.get('/api/session')
def current_session():
    if 'user_id' not in session: return jsonify(authenticated=False)
    return jsonify(authenticated=True, user={'id':session['user_id'],'name':session.get('name',''),'email':session.get('email',''),'role':session.get('role','Estudiante')})

@app.post('/api/logout')
def logout():
    session.clear()
    return jsonify(ok=True, message='Sesión cerrada.')

def require_login():
    if 'user_id' not in session: return api_error('Inicia sesión para continuar.', 401)
    return None

@app.get('/api/progress')
def get_progress():
    err = require_login()
    if err: return err
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            cur.execute('SELECT payload FROM c2_progreso_usuario WHERE id_usuario=%s', (session['user_id'],))
            row = cur.fetchone()
        if not row or not row['payload']: return jsonify(progress=None)
        try: return jsonify(progress=json.loads(row['payload']))
        except (TypeError, json.JSONDecodeError): return jsonify(progress=None)
    except mysql.connector.Error:
        app.logger.exception('Progress read failed')
        return api_error('No fue posible consultar el progreso guardado.', 503)
    finally:
        if con: con.close()

@app.post('/api/progress')
def save_progress():
    err = require_login()
    if err: return err
    data = request.get_json(silent=True) or {}
    progress = data.get('progress')
    if not isinstance(progress, dict): return api_error('Formato de progreso inválido.')
    payload = json.dumps(progress, ensure_ascii=False)
    con = None
    try:
        con = get_db_connection()
        with con.cursor() as cur:
            cur.execute('''INSERT INTO c2_progreso_usuario (id_usuario,payload,actualizado_en) VALUES (%s,%s,NOW())
                           ON DUPLICATE KEY UPDATE payload=VALUES(payload),actualizado_en=NOW()''', (session['user_id'], payload))
        con.commit()
        return jsonify(ok=True)
    except mysql.connector.Error:
        app.logger.exception('Progress save failed')
        if con: con.rollback()
        return api_error('El progreso no se pudo guardar en MySQL.', 503)
    finally:
        if con: con.close()

@app.post('/api/result')
def save_result():
    err = require_login()
    if err: return err
    data = request.get_json(silent=True) or {}
    try:
        score = max(0, min(100, int(data.get('score', 0))))
        correct = max(0, int(data.get('correct', 0)))
        total = max(1, int(data.get('total', 1)))
    except (ValueError, TypeError): return api_error('Resultado de evaluación inválido.')
    con = None
    try:
        con = get_db_connection()
        with con.cursor() as cur:
            cur.execute('INSERT INTO c2_resultado_evaluacion (id_usuario,modulo, puntaje, aciertos,total_preguntas,fecha) VALUES (%s,%s,%s,%s,%s,NOW())',
                        (session['user_id'], str(data.get('module','Basic 1'))[:120], score, correct, total))
        con.commit()
        return jsonify(ok=True)
    except mysql.connector.Error:
        app.logger.exception('Result save failed')
        if con: con.rollback()
        return api_error('No se pudo guardar el resultado. Puedes continuar y volver a intentarlo después.', 503)
    finally:
        if con: con.close()

@app.get('/api/dictionary')
def dictionary():
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            cur.execute('''SELECT s.id_sena,s.palabra,s.definicion,s.descripcion_movimiento,s.ejemplo_uso,s.nivel,c.nombre AS categoria,
                           (SELECT v.url_video FROM video v WHERE v.id_sena=s.id_sena ORDER BY v.id_video LIMIT 1) AS url_video
                           FROM sena s LEFT JOIN categoria c ON c.id_categoria=s.id_categoria ORDER BY c.nombre,s.palabra''')
            return jsonify(items=cur.fetchall())
    except mysql.connector.Error:
        app.logger.exception('Dictionary query failed')
        return api_error('No fue posible cargar el diccionario desde MySQL.', 503)
    finally:
        if con: con.close()

@app.get('/api/lessons')
def lessons():
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            cur.execute('''SELECT l.id_leccion,l.titulo,l.contenido,l.orden,l.duracion_minutos,m.nombre AS modulo,c.nombre AS curso,
                           (SELECT v.url_video FROM video v WHERE v.id_leccion=l.id_leccion ORDER BY v.id_video LIMIT 1) AS url_video
                           FROM leccion l JOIN modulo m ON m.id_modulo=l.id_modulo JOIN curso c ON c.id_curso=m.id_curso
                           ORDER BY c.id_curso,m.orden,l.orden''')
            return jsonify(items=cur.fetchall())
    except mysql.connector.Error:
        app.logger.exception('Lessons query failed')
        return api_error('No fue posible cargar las lecciones desde MySQL.', 503)
    finally:
        if con: con.close()

@app.get('/api/admin/stats')
def admin_stats():
    err = require_login()
    if err: return err
    if str(session.get('role','')).lower() not in ('administrador','admin'): return api_error('Esta sección requiere permisos de administrador.', 403)
    con = None
    try:
        con = get_db_connection()
        with con.cursor(dictionary=True) as cur:
            out = {}
            for key, table in [('usuarios','usuario'),('cursos','curso'),('lecciones','leccion'),('senas','sena')]:
                cur.execute(f'SELECT COUNT(*) AS total FROM {table}')
                out[key] = cur.fetchone()['total']
            cur.execute('SELECT COUNT(*) AS total FROM c2_resultado_evaluacion')
            out['evaluaciones'] = cur.fetchone()['total']
            return jsonify(stats=out)
    except mysql.connector.Error:
        app.logger.exception('Admin stats failed')
        return api_error('No fue posible cargar las estadísticas.', 503)
    finally:
        if con: con.close()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.environ.get('PORT','5000')), debug=False)
