# CONECTA2 | Proyecto único integrado

Aplicación web académica para el aprendizaje progresivo de la Lengua de Señas Colombiana (LSC), desarrollada con **Python, Flask, MySQL, HTML, CSS y JavaScript**. La interfaz educativa, las actividades y las API se sirven desde una sola aplicación; no hay que ejecutar una segunda web ni abrir los HTML con doble clic.

## Funcionalidades incluidas

- Registro, inicio y cierre de sesión con contraseñas almacenadas mediante hash.
- Consulta del estado de conexión a MySQL.
- Catálogo de módulos y ocho lecciones iniciales, con actividades interactivas y evaluación.
- Diccionario LSC consultado desde las tablas `sena`, `categoria` y `video`.
- Guardado de progreso y resultados de evaluación en tablas de apoyo de CONECTA2.
- Puntuación, niveles, seguimiento de avance y estadísticas básicas de administración.
- Interfaz adaptable a distintos tamaños de pantalla, navegación por teclado y mensajes de ayuda.

> **Importante sobre los recursos LSC:** la plataforma incluye espacios configurables para imágenes y videos. El material de señas debe proceder de fuentes autorizadas y ser revisado por personas competentes en LSC. Las ilustraciones o descripciones introductorias no sustituyen una demostración lingüística validada.

## Requisitos

- Windows 10/11
- Python 3.10 o superior
- MySQL/MariaDB en ejecución y MySQL Workbench
- VS Code (recomendado)

## Instalación paso a paso

### 1. Preparar la base de datos

1. Abre MySQL Workbench y conéctate a tu servidor.
2. Si la base `lsc_conecta2` **todavía no existe**, abre `lsc_conecta2.sql` y ejecútalo.
3. **Advertencia:** este archivo es un volcado de base de datos que contiene instrucciones `DROP TABLE`. Puede borrar y recrear tablas existentes. Si ya tienes información que necesitas conservar, haz una copia de seguridad y no lo ejecutes a ciegas.
4. Abre `schema_app.sql` y ejecútalo después. Este script crea las tablas auxiliares de progreso y resultados sin reemplazar las tablas originales.
5. Verifica con:

```sql
USE lsc_conecta2;
SHOW TABLES;
SHOW TABLES LIKE 'c2_progreso_usuario';
SHOW TABLES LIKE 'c2_resultado_evaluacion';
```

### 2. Configurar las credenciales

1. En la carpeta principal, copia `.env.example` y nombra la copia `.env`.
2. Abre `.env` y configura los datos reales de tu MySQL. Ejemplo:

```dotenv
MYSQL_HOST=localhost
MYSQL_PORT=3307
MYSQL_DATABASE=lsc_conecta2
MYSQL_USER=root
MYSQL_PASSWORD=TU_CLAVE_MYSQL
FLASK_SECRET_KEY=pon-una-clave-larga-y-aleatoria
```

Usa el puerto de tu instalación. En tu configuración previa la conexión funcionó en el puerto `3307`. Si tu MySQL usa `3306`, cambia ese valor. No compartas el archivo `.env` ni subas sus contraseñas a GitHub.

### 3. Instalar y arrancar

1. Abre **esta carpeta exacta** en VS Code: la que contiene `app.py` y `requirements.txt`.
2. Abre **Terminal → Nueva terminal**. Comprueba la ubicación con `dir`; deben aparecer ambos archivos.
3. Ejecuta, una línea a la vez:

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

También puedes abrir `INICIAR_CONECTA2.bat` con doble clic para instalar dependencias e iniciar el servidor.

4. No cierres la terminal mientras uses la aplicación.
5. Abre el navegador en **http://127.0.0.1:5000/**. No uses `index.html` como archivo local ni abras otro servidor para la misma plataforma.

### 4. Crear cuenta y comprobar la conexión

- En la interfaz, usa el formulario de registro para crear tu cuenta de estudiante.
- Si necesitas crearla desde terminal, ejecuta `python crear_usuario.py` con el entorno virtual activado.
- Para comprobar la conexión abre `http://127.0.0.1:5000/api/health`. Si MySQL responde, el JSON indica `"database": "connected"`.

## Añadir imágenes y videos

Los valores de ejemplo están centralizados en `static/js/config.js` y `static/js/data.js`. Reemplaza los marcadores `AQUI_DEBES_PONER...` por URLs de imágenes autorizadas y videos válidos. Para incrustar videos de YouTube, usa una URL de inserción (`https://www.youtube.com/embed/ID_DEL_VIDEO`), no la URL normal de búsqueda. También puedes poner archivos propios dentro de una carpeta `static/media/` y referenciarlos como `/static/media/nombre-del-archivo.mp4` o `/static/media/nombre-de-imagen.jpg`.

Antes de publicar recursos de LSC, confirma permisos de uso, atribución y exactitud con una fuente o persona competente. No presentes material provisional como validado.

## Relación con la documentación de Calidad de Software

El alcance corresponde al MVP descrito en la propuesta: usuarios, categorías, lecciones, recursos audiovisuales configurables, actividades, evaluaciones, puntuación, progreso y administración básica. Se incluye `documentacion/PLAN_DE_PRUEBAS_Y_CALIDAD.md` como matriz inicial para verificar los requisitos funcionales y criterios de calidad. La aplicación es una base académica local, no un despliegue de producción certificado.

## Solución rápida de errores

- **`requirements.txt` no existe:** la terminal está en otra carpeta. Abre la carpeta que contiene `app.py` y ejecuta `dir`.
- **`ModuleNotFoundError`:** activa `.venv` e instala dependencias con `python -m pip install -r requirements.txt`.
- **Error de conexión:** confirma que MySQL esté iniciado y revisa host, puerto, usuario y contraseña en `.env`.
- **`Unknown database`:** confirma que se importó la base `lsc_conecta2`.
- **El navegador entra y se sale / no carga:** deja la terminal abierta y revisa el error que aparezca allí. No inicies otra copia del servidor en el mismo puerto.
- **No inicia sesión:** crea una cuenta con el formulario de registro. Las cuentas de ejemplo antiguas no son necesarias.

## Estructura única

```text
CONECTA2_PROYECTO_UNICO/
├── app.py
├── db.py
├── crear_usuario.py
├── index.html
├── requirements.txt
├── .env.example
├── lsc_conecta2.sql
├── schema_app.sql
├── migracion_racha.sql
├── static/
│   ├── css/styles.css
│   └── js/{app.js,config.js,data.js}
├── documentacion/PLAN_DE_PRUEBAS_Y_CALIDAD.md
└── INICIAR_CONECTA2.bat
```
