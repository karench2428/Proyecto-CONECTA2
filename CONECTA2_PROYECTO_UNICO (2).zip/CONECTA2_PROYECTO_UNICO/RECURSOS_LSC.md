# Recursos visuales y audiovisuales para CONECTA2

- Las lecciones incluyen un acceso a búsquedas de videos educativos de Lengua de Señas Colombiana en YouTube. Se abre en una pestaña nueva para no inventar enlaces de videos que no se han validado.
- El archivo SQL original contiene algunas URLs `ejemplo.com`; son datos de demostración y no son videos reales. Sustitúyelas en la tabla `video` por enlaces autorizados y revisados antes de presentar el proyecto.
- Las ilustraciones con iconos de la interfaz son orientativas, no muestran configuraciones exactas de manos. Para enseñar el abecedario y vocabulario, incorpora fotografías o videos validados por una persona competente en LSC.
- La interfaz usa una paleta propia: verde petróleo `#147D78`, azul pizarra `#243B53`, crema `#F6F3ED` y terracota `#E89B5B`.

## Endpoints Flask disponibles
- `GET /api/session`: estado de autenticación.
- `POST /api/login`: inicia sesión con la tabla `usuario`.
- `POST /api/logout`: cierra la sesión.
- `GET /api/dictionary`: consulta el vocabulario de las tablas `sena` y `categoria`.
- `GET /api/lessons`: consulta lecciones, módulos y cursos.

Nota: las cuentas de demostración del SQL tienen contraseñas de texto ficticias como `HashDemo001`, no hashes válidos para iniciar sesión. Crea una cuenta con contraseña cifrada para probar el login. El avance de lecciones de la interfaz todavía se guarda localmente en el navegador; no se debe presentar como progreso persistido en MySQL.
