/* ============================================================================
   DATOS DEL CURSO
   ----------------------------------------------------------------------------
   Todo el contenido educativo vive en este archivo, separado de la lógica.
   Para agregar o modificar lecciones, edita este archivo sin tocar app.js.

   ESTRUCTURA DE UNA LECCIÓN
   ---------------------------------------------------------------------------
   {
     id, numero, titulo, descripcion, objetivo,
     imagen:   URL configurable (marcador en config.js),
     video:    URL configurable (marcador en config.js),
     contenido: [ {tipo: "texto"|"lista"|"subtitulo"|"nota"|"media"|"vocabulario"} ],
     actividad: { tipo: "opcion" | "relacionar", ... }
   }

   TIPOS DE BLOQUE DE CONTENIDO
   ---------------------------------------------------------------------------
   texto       → { tipo:"texto", html:"..." }
   subtitulo   → { tipo:"subtitulo", texto:"..." }
   lista       → { tipo:"lista", items:["...","..."] }
   nota        → { tipo:"nota", html:"..." }            (caja destacada)
   media       → { tipo:"media", url, alt, leyenda }     (imagen/video)
   vocabulario → { tipo:"vocabulario", items:[{termino, seña, detalle}] }

   TIPOS DE ACTIVIDAD
   ---------------------------------------------------------------------------
   opcion     → pregunta de selección múltiple de una sola pregunta.
   relacionar → relacionar dos columnas (clic izquierda → clic derecha).

   IMPORTANTE: el material lingüístico visual (fotos/videos de señas) y las
   descripciones configuracionales están marcados para validación por personas
   competentes en LSC. No se presentan como señas confirmadas.
   ============================================================================
*/

/* --- Utilidad para construir marcadores de imagen/video desde config.js --- */
const PENDIENTE_IMAGEN = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN";
const PENDIENTE_VIDEO  = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO";

/* ============================================================================
   CURSO COMPLETO
   ============================================================================
*/
const CURSO = {
  nombre: "Curso de Lengua de Señas Colombiana",
  nivelInicial: "basic-1",

  modulos: [
    /* ======================================================================
       MÓDULO 1: BASIC 1 (completamente funcional)
       ======================================================================*/
    {
      id: "basic-1",
      titulo: "Basic 1",
      subtitulo: "Fundamentos de la LSC",
      estado: "activo",
      imagen: URL_IMAGEN_MODULO_BASIC_1,
      descripcion:
        "Tu punto de partida: conoce la Lengua de Señas Colombiana, practica el alfabeto " +
        "manual y aprende vocabulario básico para situaciones cotidianas. Al terminar " +
        "realizarás una evaluación final.",
      lecciones: [
        /* ------------------------------ LECCIÓN 1 ------------------------ */
        {
          id: "l1",
          numero: 1,
          titulo: "Introducción a la LSC",
          descripcion:
            "Qué es la Lengua de Señas Colombiana, por qué es importante y cómo difiere " +
            "de simplemente señalar palabras en español.",
          objetivo:
            "Reconocer la LSC como una lengua completa y natural, y explicar por qué su " +
            "aprendizaje favorece la comunicación inclusiva.",
          imagen: URL_IMAGEN_LECCION_1,
          video: URL_VIDEO_LECCION_1,
          contenido: [
            { tipo: "subtitulo", texto: "¿Qué es la Lengua de Señas Colombiana?" },
            {
              tipo: "texto",
              html:
                "La Lengua de Señas Colombiana (LSC) es la lengua natural de la comunidad " +
                "sorda en Colombia. Como toda lengua natural, tiene su propia gramática, su " +
                "sintaxis y sus formas de expresión; <strong>no es un código secreto ni un " +
                "sistema de señas aislado</strong>, sino un sistema lingüístico completo que " +
                "se articula con las manos, el rostro, el cuerpo y el espacio frente a la persona."
            },
            {
              tipo: "media",
              url: URL_VIDEO_PRESENTACION,
              alt: "Video de presentación de señas en Lengua de Señas Colombiana",
              leyenda: "Espacio para un video de presentación de la LSC (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "¿Por qué es importante aprenderla?" },
            {
              tipo: "lista",
              items: [
                "Permite comunicarte directamente con personas sordas, sin depender de un intermediario.",
                "Fortalece una comunicación más inclusiva en la escuela, el trabajo y la familia.",
                "Ayuda a desarrollar mayor conciencia sobre la diversidad lingüística y cultural.",
                "Enriquece tu forma de observar el lenguaje: expresa ideas con las manos, el rostro y el espacio."
              ]
            },
            { tipo: "subtitulo", texto: "Lengua de señas ≠ gestos del español" },
            {
              tipo: "texto",
              html:
                "Un error muy común es pensar que la LSC es el español convertido en gestos. " +
                "En realidad <strong>son lenguas distintas</strong>: la LSC no sigue el orden " +
                "gramatical del español hablado, usa el espacio para organizar la información " +
                "y emplea el rostro para expresar gramática y estados emocionales. Traducir " +
                "palabra por palabra del español a señas produce mensajes confusos."
            },
            {
              tipo: "lista",
              items: [
                "El español se organiza con sonidos; la LSC se organiza con formas visuales en el espacio.",
                "En LSC, la ubicación de una señal en el espacio puede indicar quién hace qué acción.",
                "La expresión facial no es \"emoción extra\": forma parte de la gramática de la lengua.",
                "Deletrear con el alfabeto manual se usa para nombres propios, no para \"escribir en señas\"."
              ]
            },
            { tipo: "subtitulo", texto: "Recomendaciones para aprender con respeto" },
            {
              tipo: "nota",
              html:
                "Aprende junto a la comunidad sorda: ellos y ellas son las personas expertas " +
                "en su lengua. Usa el material visual con <strong>crédito y respeto</strong>, " +
                "evita imitar señas fuera de contexto para hacer reír, y recuerda que una lengua " +
                "se aprende practicando con personas, no solo mirando videos."
            },
            {
              tipo: "lista",
              items: [
                "Practica con regularidad, aunque sean 15 minutos diarios.",
                "Observa atentamente el rostro y el cuerpo, no solo las manos.",
                "Sé paciente contigo: al principio todos cometen errores y eso es normal.",
                "Respeta a las personas sordas: no las trates como si no pudieran aprender o decidir."
              ]
            }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "¿Cuál de estas afirmaciones describe correctamente la LSC?",
            opciones: [
              { texto: "Es un conjunto de gestos que copia palabra por palabra el español.", correcta: false },
              { texto: "Es una lengua natural con gramática propia, usada por la comunidad sorda de Colombia.", correcta: true },
              { texto: "Es un código secreto inventado para comunicarse en privado.", correcta: false },
              { texto: "Es la mímica que se usa únicamente para acompañar el sonido.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Exacto! La LSC es una lengua completa, no una traducción gestual del español.",
            retroalimentacionIncorrecta: "Revisa la lección: la LSC tiene gramática propia y no es una copia gestual del español."
          }
        },

        /* ------------------------------ LECCIÓN 2 ------------------------ */
        {
          id: "l2",
          numero: 2,
          titulo: "Alfabeto manual",
          descripcion:
            "Presentación del alfabeto manual colombiano, la herramienta que permite " +
            "deletrear nombres y palabras que todavía no tienen una señal propia.",
          objetivo:
            "Reconocer la función del alfabeto manual y familiarizarse con la representación " +
            "de las letras del español en LSC.",
          imagen: URL_IMAGEN_LECCION_2,
          video: URL_VIDEO_LECCION_2,
          contenido: [
            { tipo: "subtitulo", texto: "¿Para qué sirve el alfabeto manual?" },
            {
              tipo: "texto",
              html:
                "El alfabeto manual (también llamado <em>dactilología</em>) es el conjunto de " +
                "configuraciones de mano que representan las letras del español. Se utiliza " +
                "principalmente para <strong>nombres propios, apellidos, lugares y palabras " +
                "que todavía no tienen una señal reconocida</strong> en la comunidad. " +
                "Deletrear no significa \"hablar en señas\": es una herramienta complementaria " +
                "de una lengua que tiene sus propias palabras señadas."
            },
            { tipo: "subtitulo", texto: "El alfabeto colombiano" },
            {
              tipo: "texto",
              html:
                "A continuación se muestran las 27 letras del español que se practican en el " +
                "alfabeto manual colombiano. En cada tarjeta tienes un espacio para colocar la " +
                "imagen o el video de la configuración de la letra (URL editable en " +
                "<code>js/data.js</code>, campo <code>media</code> de cada letra)."
            },
            {
              tipo: "nota",
              html:
                "<strong>Material pendiente de validación:</strong> las configuraciones de mano, " +
                "orientación y movimiento de cada letra deben mostrarse con material visual " +
                "revisado por personas competentes en LSC. Por eso las tarjetas muestran un " +
                "espacio de reemplazo hasta que se agreguen las URLs."
            },
            { tipo: "subtitulo", texto: "Consejos para practicar" },
            {
              tipo: "lista",
              items: [
                "Coloca la mano a la altura del hombro, cerca del rostro, para que sea fácil de ver.",
                "Mantén la mano firme y evita moverla mientras deletreas.",
                "Deletrea a un ritmo constante, sin apurarte: la claridad es más importante que la velocidad.",
                "Practica deletreando tu nombre, el de tus amigos y palabras cotidianas."
              ]
            }
          ],
          /* Espacios individuales por letra (imagen o video configurable) */
          alfabeto: [
            { letra: "A", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "B", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "C", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "D", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "E", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "F", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "G", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "H", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "I", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "J", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "K", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "L", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "M", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "N", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "Ñ", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "O", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "P", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "Q", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "R", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "S", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "T", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "U", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "V", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "W", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "X", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "Y", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { letra: "Z", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "¿Para qué se utiliza principalmente el alfabeto manual en LSC?",
            opciones: [
              { texto: "Para escribir frases completas porque la LSC no tiene palabras propias.", correcta: false },
              { texto: "Para nombres propios, apellidos, lugares y palabras sin una señal reconocida.", correcta: true },
              { texto: "Para reemplazar el rostro y la expresión facial durante la comunicación.", correcta: false },
              { texto: "Únicamente para deletrear el abecedario completo en cada conversación.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Muy bien! El alfabeto manual se usa sobre todo para nombres y palabras sin señal propia.",
            retroalimentacionIncorrecta: "Revisa: la LSC tiene sus propias palabras; el alfabeto manual complementa para nombres y términos específicos."
          }
        },

        /* ------------------------------ LECCIÓN 3 ------------------------ */
        {
          id: "l3",
          numero: 3,
          titulo: "Saludos y despedidas",
          descripcion:
            "Expresiones básicas para saludar y despedirte: el primer intercambio en cualquier " +
            "conversación en LSC.",
          objetivo:
            "Identificar y usar las señas de saludo y despedida más comunes en situaciones " +
            "cotidianas.",
          imagen: URL_IMAGEN_LECCION_3,
          video: URL_VIDEO_LECCION_3,
          contenido: [
            { tipo: "subtitulo", texto: "El inicio de una conversación" },
            {
              tipo: "texto",
              html:
                "Al encontrarte con una persona sorda, el saludo funciona igual que en el español " +
                "hablado: genera confianza y abre la comunicación. En LSC, un saludo suele " +
                "acompañarse de <strong>contacto visual</strong> y de la expresión facial " +
                "correspondiente: una sonrisa o un gesto amable forma parte del saludo."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_3,
              alt: "Demostración de saludos y despedidas en Lengua de Señas Colombiana",
              leyenda: "Espacio para video demostrativo de saludos y despedidas (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Vocabulario básico de esta lección" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "Hola", seña: "Saludo básico", detalle: "Se usa a cualquier hora del día. Acompaña con contacto visual y expresión amable." },
                { termino: "Buenos días", seña: "Saludo matutino", detalle: "Saludo formal para la primera parte del día." },
                { termino: "Buenas tardes", seña: "Saludo de la tarde", detalle: "Se usa desde el mediodía hasta el atardecer." },
                { termino: "Buenas noches", seña: "Saludo/despedida nocturno", detalle: "Sirve tanto para saludar como para despedirse de noche." },
                { termino: "¿Cómo estás?", seña: "Pregunta de cortesía", detalle: "Pregunta habitual tras el saludo; la expresión facial indica que es una pregunta." },
                { termino: "Bien / Mal", seña: "Respuesta a cómo estás", detalle: "La expresión facial acompaña la respuesta: alegre si está bien, preocupada si está mal." },
                { termino: "Adiós", seña: "Despedida", detalle: "Se realiza con la mano alzada y un movimiento dirigido a la persona." },
                { termino: "Hasta luego", seña: "Despedida con esperanza de volver a verse", detalle: "Indica que habrá un encuentro posterior." },
                { termino: "Por favor", seña: "Cortesía", detalle: "Se usa para pedir o solicitar algo con amabilidad." },
                { termino: "Gracias", seña: "Agradecimiento", detalle: "Puede ir acompañado de una ligera inclinación de la cabeza." }
              ]
            },
            { tipo: "subtitulo", texto: "Ejemplo práctico" },
            {
              tipo: "texto",
              html:
                "Imagina que llegas a un salón y ves a una persona sorda. La secuencia natural es: " +
                "<strong>contacto visual → «Hola» → «¿Cómo estás?»</strong>. Al irte, cierras con " +
                "«Adiós» o «Hasta luego». Mantener el contacto visual durante el intercambio es " +
                "una señal de respeto y atención."
            },
            {
              tipo: "nota",
              html:
                "Recuerda: las señas específicas de cada expresión deben practicarse con el " +
                "material visual validado por la comunidad sorda. Este contenido prepara el " +
                "vocabulario y el contexto de uso."
            }
          ],
          actividad: {
            tipo: "relacionar",
            tituloActividad: "Relaciona cada expresión con su situación de uso",
            pares: [
              { izquierda: "Buenos días", derecha: "Saludar por la mañana" },
              { izquierda: "¿Cómo estás?", derecha: "Preguntar por el estado de la persona" },
              { izquierda: "Gracias", derecha: "Agradecer algo" },
              { izquierda: "Hasta luego", derecha: "Despedirse con la idea de volver a vernos" }
            ],
            retroalimentacionCorrecta: "¡Correcto! Ya reconoces las situaciones de uso de estas expresiones.",
            retroalimentacionIncorrecta: "Algunas parejas no coinciden. Vuelve a leer la descripción de cada expresión."
          }
        },

        /* ------------------------------ LECCIÓN 4 ------------------------ */
        {
          id: "l4",
          numero: 4,
          titulo: "Presentación personal",
          descripcion:
            "Vocabulario y estructura para presentarte: tu nombre, de dónde eres y a qué te " +
            "dedicas.",
          objetivo:
            "Construir una presentación personal sencilla usando el vocabulario básico de LSC " +
            "y el alfabeto manual para el nombre.",
          imagen: URL_IMAGEN_LECCION_4,
          video: URL_VIDEO_LECCION_4,
          contenido: [
            { tipo: "subtitulo", texto: "¿Cómo me presento en LSC?" },
            {
              tipo: "texto",
              html:
                "Presentarse es una de las primeras situaciones que practicarás. En LSC, una " +
                "presentación suele ordenarse así: <strong>nombre → lugar de origen → " +
                "ocupación o actividad</strong>. Tu nombre normalmente se deletrea con el " +
                "alfabeto manual, y si tienes una señal propia (apodo señalado), puedes usarla " +
                "y después deletrearla para confirmar."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_4,
              alt: "Ejemplo de presentación personal en Lengua de Señas Colombiana",
              leyenda: "Espacio para video de ejemplo de presentación personal (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Vocabulario útil" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "Me llamo…", seña: "Presentar el nombre", detalle: "Se acompaña deletreando el nombre con el alfabeto manual." },
                { termino: "Yo soy de…", seña: "Indicar el lugar de origen", detalle: "Señalas el lugar (ciudad/país) en el espacio de la conversación." },
                { termino: "Estudiante", seña: "Ocupación: estudiante", detalle: "Palabra señalada para la actividad de estudio." },
                { termino: "Trabajo en…", seña: "Indicar lugar de trabajo", detalle: "Combina la señal de \"trabajo\" con el lugar." },
                { termino: "Mucho gusto", seña: "Cortesía al conocernos", detalle: "Se usa al terminar la presentación; expresa agrado por el encuentro." },
                { termino: "¿Y tú?", seña: "Devolver la pregunta", detalle: "Devuelve la presentación a la otra persona; la mirada indica la pregunta." }
              ]
            },
            { tipo: "subtitulo", texto: "Ejemplo de diálogo" },
            {
              tipo: "texto",
              html:
                "<strong>Ana:</strong> «Hola, me llamo A-N-A, yo soy de Bogotá, estudiante.»<br>" +
                "<strong>Luis:</strong> «Mucho gusto, Ana. Yo me llamo L-U-I-S, soy de Medellín.»<br>" +
                "<strong>Ana:</strong> «¿Y tú, de dónde eres?» — la expresión facial y la mirada " +
                "hacia la otra persona marcan la pregunta."
            }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "¿Cuál es el orden recomendado para una presentación personal en LSC?",
            opciones: [
              { texto: "Ocupación → lugar de nacimiento → nombre.", correcta: false },
              { texto: "Nombre → lugar de origen → ocupación o actividad.", correcta: true },
              { texto: "Únicamente deletrear el nombre completo, sin más información.", correcta: false },
              { texto: "Saludo, número de documento y dirección exacta.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Correcto! Nombre, origen y actividad es una secuencia natural de presentación.",
            retroalimentacionIncorrecta: "Revisa el ejemplo de diálogo: la presentación va nombre → origen → actividad."
          }
        },

        /* ------------------------------ LECCIÓN 5 ------------------------ */
        {
          id: "l5",
          numero: 5,
          titulo: "Números básicos",
          descripcion:
            "Aprende a reconocer y usar los números del 1 al 10 en situaciones cotidianas: " +
            "edades, cantidades y orden.",
          objetivo:
            "Identificar los números del 1 al 10 en LSC y usarlos en contextos sencillos.",
          imagen: URL_IMAGEN_LECCION_5,
          video: URL_VIDEO_LECCION_5,
          contenido: [
            { tipo: "subtitulo", texto: "Los números del 1 al 10" },
            {
              tipo: "texto",
              html:
                "Los números son uno de los vocabularios más útiles al empezar. Se usan para " +
                "cantidades, edades, horas,teléfonos y orden. En esta lección practicamos los " +
                "números del 1 al 10; en módulos avanzados ampliaremos a decenas y centenas."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_5,
              alt: "Demostración de números del 1 al 10 en Lengua de Señas Colombiana",
              leyenda: "Espacio para video demostrativo de números (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Usos cotidianos de los números" },
            {
              tipo: "lista",
              items: [
                "Edades: «¿Cuántos años tienes?» + respuesta con el número.",
                "Cantidades: cuántas personas, cuántos objetos, cuántos días.",
                "Horas y citas: la hora de una reunión o de una clase.",
                "Teléfonos y direcciones: se deletrean o se señan según el contexto."
              ]
            },
            { tipo: "subtitulo", texto: "Tabla de referencia (1 al 10)" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "1", seña: "Número uno", detalle: "Espacio para imagen/video del número 1 en LSC." },
                { termino: "2", seña: "Número dos", detalle: "Espacio para imagen/video del número 2 en LSC." },
                { termino: "3", seña: "Número tres", detalle: "Espacio para imagen/video del número 3 en LSC." },
                { termino: "4", seña: "Número cuatro", detalle: "Espacio para imagen/video del número 4 en LSC." },
                { termino: "5", seña: "Número cinco", detalle: "Espacio para imagen/video del número 5 en LSC." },
                { termino: "6", seña: "Número seis", detalle: "Espacio para imagen/video del número 6 en LSC." },
                { termino: "7", seña: "Número siete", detalle: "Espacio para imagen/video del número 7 en LSC." },
                { termino: "8", seña: "Número ocho", detalle: "Espacio para imagen/video del número 8 en LSC." },
                { termino: "9", seña: "Número nueve", detalle: "Espacio para imagen/video del número 9 en LSC." },
                { termino: "10", seña: "Número diez", detalle: "Espacio para imagen/video del número 10 en LSC." }
              ]
            },
            {
              tipo: "nota",
              html: "Cada casilla de la tabla tiene un espacio reservado para la imagen o el video " +
                    "de la seña correspondiente. Agrega las URLs en el arreglo <code>numero</code> " +
                    "de esta lección (ver <code>js/data.js</code>)."
            }
          ],
          /* Espacios individuales por número (imagen o video configurable) */
          numeros: [
            { numero: "1", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "2", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "3", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "4", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "5", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "6", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "7", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "8", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "9", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { numero: "10", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "Si una persona sorda pregunta «¿Cuántos años tienes?», ¿qué vocabulario usarías para responder que tienes 12 años?",
            opciones: [
              { texto: "Deletrear \"doce\" letra por letra con el alfabeto manual.", correcta: false },
              { texto: "Señar el número 12 (decena + unidad) como parte de la respuesta.", correcta: true },
              { texto: "Señalar el número 1 y luego el número 2 rápidamente sin pausa.", correcta: false },
              { texto: "Escribir la respuesta en una hoja de papel.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Bien! Los números se usan directamente en respuestas de cantidades y edades.",
            retroalimentacionIncorrecta: "Repasa la tabla: los números se señan como vocabulario propio, no se deletrean."
          }
        },

        /* ------------------------------ LECCIÓN 6 ------------------------ */
        {
          id: "l6",
          numero: 6,
          titulo: "Familia y personas",
          descripcion:
            "Vocabulario para hablar de las personas importantes de tu vida: familiares y " +
            "relaciones cercanas.",
          objetivo:
            "Reconocer y usar el vocabulario básico relacionado con la familia y las personas " +
            "cercanas.",
          imagen: URL_IMAGEN_LECCION_6,
          video: URL_VIDEO_LECCION_6,
          contenido: [
            { tipo: "subtitulo", texto: "Hablar de la familia en LSC" },
            {
              tipo: "texto",
              html:
                "Hablar de la familia es uno de los temas más comunes al conocer a alguien. " +
                "En LSC, muchas señas de parentesco se ubican en zonas del rostro o del cuerpo " +
                "relacionadas con quién realiza la acción (por ejemplo, señas vinculadas a " +
                "\"madre\" o \"padre\"), y el concepto de \"hermano/a\" se relaciona con " +
                "personas que comparten espacio familiar. En esta lección trabajamos el " +
                "<strong>reconocimiento del vocabulario</strong> con material visual validado."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_6,
              alt: "Vocabulario de familia en Lengua de Señas Colombiana",
              leyenda: "Espacio para video de vocabulario de familia (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Vocabulario básico de familia" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "Familia", seña: "Grupo familiar", detalle: "Concepto general; suele realizarse con un movimiento circular que abarca al grupo." },
                { termino: "Madre / Mamá", seña: "Parentesco: madre", detalle: "Seña de parentesco femenino; ubicación y configuración por validar con material visual." },
                { termino: "Padre / Papá", seña: "Parentesco: padre", detalle: "Seña de parentesco masculino; ubicación y configuración por validar con material visual." },
                { termino: "Hermano / Hermana", seña: "Parentesco: hermano/a", detalle: "Se usa también para compañeros cercanos en algunos contextos." },
                { termino: "Abuelo / Abuela", seña: "Parentesco: abuelo/a", detalle: "Seña de la generación mayor." },
                { termino: "Hijo / Hija", seña: "Parentesco: hijo/a", detalle: "Seña de la generación menor." },
                { termino: "Amigo / Amiga", seña: "Persona cercana no familiar", detalle: "Relación de amistad; suele realizarse con ambas manos." },
                { termino: "Maestro / Maestra", seña: "Persona que enseña", detalle: "Útil para presentar a tus profesores." }
              ]
            },
            {
              tipo: "nota",
              html:
                "<strong>Material pendiente de validación:</strong> las señas de parentesco " +
                "deben practicarse con el video o las fotografías revisadas por la comunidad " +
                "sorda. Este listado organiza el vocabulario y su contexto de uso."
            },
            { tipo: "subtitulo", texto: "Ejemplo práctico" },
            {
              tipo: "texto",
              html:
                "Para presentar a tu familia: «Yo tengo mamá, papá y una hermana. Mi hermana " +
                "estudia.» En LSC, la información suele organizarse en el espacio: una vez " +
                "presentas a una persona con una señal, puedes referirte a ella señalando ese " +
                "mismo lugar para indicar quién hace la acción."
            }
          ],
          actividad: {
            tipo: "relacionar",
            tituloActividad: "Relaciona cada término con su significado",
            pares: [
              { izquierda: "Madre", derecha: "Parentesco con la mamá" },
              { izquierda: "Hermano", derecha: "Persona que comparte familia contigo" },
              { izquierda: "Abuelo", derecha: "Parentesco de la generación mayor" },
              { izquierda: "Amigo", derecha: "Persona cercana que no es familiar" }
            ],
            retroalimentacionCorrecta: "¡Correcto! Ya identificas el vocabulario básico de familia.",
            retroalimentacionIncorrecta: "Revisa el listado de vocabulario e inténtalo de nuevo."
          }
        },

        /* ------------------------------ LECCIÓN 7 ------------------------ */
        {
          id: "l7",
          numero: 7,
          titulo: "Colores",
          descripcion:
            "Aprende a describir el color de objetos, ropa y personas usando vocabulario básico " +
            "de colores en LSC.",
          objetivo:
            "Identificar señas de colores básicos y usarlas para describir objetos sencillos.",
          imagen: URL_IMAGEN_LECCION_7,
          video: URL_VIDEO_LECCION_7,
          contenido: [
            { tipo: "subtitulo", texto: "Describir con colores" },
            {
              tipo: "texto",
              html:
                "Los colores permiten describir el entorno: la ropa, los objetos, los deportes " +
                "o los símbolos. En LSC, muchas señas de colores se ubican en la zona del " +
                "labbios o del rostro, o se relacionan con el lugar donde ese color aparece " +
                "en el cuerpo (por ejemplo, colores asociados a prendas). La expresión facial " +
                "acompaña la descripción, especialmente al comparar (\"más oscuro\", \"muy claro\")."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_7,
              alt: "Vocabulario de colores en Lengua de Señas Colombiana",
              leyenda: "Espacio para video demostrativo de colores (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Colores básicos" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "Rojo", seña: "Color rojo", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Azul", seña: "Color azul", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Amarillo", seña: "Color amarillo", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Verde", seña: "Color verde", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Blanco", seña: "Color blanco", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Negro", seña: "Color negro", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Naranja", seña: "Color naranja", detalle: "Espacio para imagen/video; configuración por validar con material visual." },
                { termino: "Rosa", seña: "Color rosa", detalle: "Espacio para imagen/video; configuración por validar con material visual." }
              ]
            },
            { tipo: "subtitulo", texto: "Ejemplo práctico" },
            {
              tipo: "texto",
              html:
                "Describir una mochila: «Mochila, color azul, grande.» En LSC la descripción " +
                "suele ir después del objeto y puede combinarse con señas de tamaño y forma. " +
                "Practica describiendo objetos de tu escritorio usando color + tamaño."
            },
            {
              tipo: "nota",
              html:
                "Cada casilla de colores incluye un espacio de reemplazo para la imagen o el " +
                "video de la seña. Agrega las URLs en el arreglo <code>colores</code> de esta " +
                "lección en <code>js/data.js</code>."
            }
          ],
          /* Espacios individuales por color (imagen o video configurable) */
          colores: [
            { color: "Rojo",    hex: "#E53935", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Azul",    hex: "#2878C8", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Amarillo",hex: "#FFD447", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Verde",   hex: "#43A047", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Blanco",  hex: "#FFFFFF", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Negro",   hex: "#243247", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Naranja", hex: "#F57C00", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" },
            { color: "Rosa",    hex: "#EC407A", media: "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN" }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "¿Cuál de estas frases es un ejemplo correcto de descripción en LSC usando colores?",
            opciones: [
              { texto: "«Mochila, color azul, grande» (objeto + color + tamaño).", correcta: true },
              { texto: "Repetir en voz alta «azul, azul, azul» varias veces.", correcta: false },
              { texto: "Deletrear la palabra \"azul\" siempre, porque los colores no tienen seña.", correcta: false },
              { texto: "Señalar el color en la ropa de la otra persona sin decir nada más.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Exacto! En LSC la descripción se organiza con señas: objeto, color y tamaño.",
            retroalimentacionIncorrecta: "Repasa el ejemplo práctico: los colores se usan como vocabulario dentro de una descripción."
          }
        },

        /* ------------------------------ LECCIÓN 8 ------------------------ */
        {
          id: "l8",
          numero: 8,
          titulo: "Expresiones cotidianas",
          descripcion:
            "Repaso general con expresiones de uso frecuente: pedir, preguntar, entender o no " +
            "entender, y situaciones comunicativas sencillas.",
          objetivo:
            "Usar expresiones cotidianas para mantener una conversación básica y resolver " +
            "situaciones comunicativas sencillas.",
          imagen: URL_IMAGEN_LECCION_8,
          video: URL_VIDEO_LECCION_8,
          contenido: [
            { tipo: "subtitulo", texto: "Expresiones que necesitarás desde el primer día" },
            {
              tipo: "texto",
              html:
                "Esta lección reúne expresiones que aparecen en casi todas las conversaciones: " +
                "pedir algo, preguntar, indicar que no entendiste y pedir que repitan. Son " +
                "herramientas de <strong>reparación comunicativa</strong>: te permiten " +
                "seguir conversando aunque no conozcas todavía todas las señas."
            },
            {
              tipo: "media",
              url: URL_VIDEO_LECCION_8,
              alt: "Expresiones cotidianas en Lengua de Señas Colombiana",
              leyenda: "Espacio para video de expresiones cotidianas (URL editable en js/config.js)."
            },
            { tipo: "subtitulo", texto: "Vocabulario esencial" },
            {
              tipo: "vocabulario",
              items: [
                { termino: "No entiendo", seña: "Indicar falta de comprensión", detalle: "Acompáñalo con expresión facial de no comprender; es una frase muy valorada." },
                { termino: "Otra vez / Repite", seña: "Pedir que repitan", detalle: "Útil cuando la señal fue rápida o no la viste bien." },
                { termino: "Entiendo", seña: "Confirmar comprensión", detalle: "Cierre positivo del intercambio." },
                { termino: "Sí / No", seña: "Respuestas afirmativa y negativa", detalle: "La cabeza suele acompañar: asentir o negar con la mirada." },
                { termino: "¿Qué significa?", seña: "Preguntar el significado de una señal", detalle: "Permite aprender vocabulario nuevo en contexto." },
                { termino: "Espera", seña: "Pedir un momento", detalle: "Útil cuando necesitas pensar antes de responder." },
                { termino: "¿Dónde…?", seña: "Pregunta de lugar", detalle: "Señar el lugar en el espacio mientras preguntas." },
                { termino: "Ayuda", seña: "Pedir ayuda", detalle: "Expresión básica para situaciones de necesidad." }
              ]
            },
            { tipo: "subtitulo", texto: "Situación comunicativa 1: en la tienda" },
            {
              tipo: "texto",
              html:
                "«Hola, ¿cuánto cuesta?» → «No entiendo, otra vez» → la persona repite → " +
                "«Ah, gracias». Fíjate cómo usar «no entiendo» y «otra vez» mantiene la " +
                "conversación viva en lugar de abandonarla."
            },
            { tipo: "subtitulo", texto: "Situación comunicativa 2: en clase" },
            {
              tipo: "texto",
              html:
                "El profesor explica una señal nueva y tú preguntas: «¿Qué significa?» y " +
                "«Otra vez». Después confirmas: «Entiendo». Pedir repeticiones no es una " +
                "debilidad: es una estrategia normal y respetuosa de aprendizaje."
            },
            {
              tipo: "nota",
              html:
                "Repaso general: esta lección recupera vocabulario de lecciones anteriores " +
                "(saludos, números, familia, colores) integrado en conversaciones. Es el " +
                "último contenido antes de la evaluación final."
            }
          ],
          actividad: {
            tipo: "opcion",
            pregunta: "Durante una conversación en LSC no entiendes una señal. ¿Qué es lo más apropiado?",
            opciones: [
              { texto: "Abandonar la conversación sin decir nada.", correcta: false },
              { texto: "Señar «no entiendo» y pedir «otra vez» con la expresión facial correspondiente.", correcta: true },
              { texto: "Reírte y fingir que sí entendiste.", correcta: false },
              { texto: "Deletrear toda tu frase con el alfabeto manual.", correcta: false }
            ],
            retroalimentacionCorrecta: "¡Perfecto! «No entiendo» y «otra vez» son estrategias de reparación comunicativa muy importantes.",
            retroalimentacionIncorrecta: "Repasa la sección de situaciones comunicativas: pedir repetición es siempre mejor que abandonar."
          }
        }
      ],

      /* ===================== EVALUACIÓN FINAL DE BASIC 1 =================== */
      evaluacion: {
        titulo: "Evaluación final de Basic 1",
        descripcion:
          "Responde las siguientes preguntas sobre los contenidos vistos en las 8 lecciones. " +
          "Necesitas al menos el " + PORCENTAJE_APROBACION + " % para aprobar.",
        imagenAyuda: URL_IMAGEN_LECCION_1, // Imagen de apoyo para la evaluación (URL editable)
        preguntas: [
          {
            id: "p1",
            enunciado: "¿Qué es la Lengua de Señas Colombiana?",
            opciones: [
              "Una lengua natural con gramática propia, usada por la comunidad sorda de Colombia.",
              "Un conjunto de gestos que copia palabra por palabra el español hablado.",
              "Un código inventado por académicos para enseñar mímica.",
              "Una forma de hacer señales solo para acompañar el sonido."
            ],
            correcta: 0
          },
          {
            id: "p2",
            enunciado: "¿Cuál de estas ideas sobre la LSC es correcta?",
            opciones: [
              "La expresión facial es solo emoción y no aporta nada a la lengua.",
              "Basta con deletrear todo con el alfabeto manual para comunicarse.",
              "La LSC tiene su propia organización gramatical y usa el espacio para expresar relaciones.",
              "Las señas son iguales en todos los países hispanohablantes."
            ],
            correcta: 2
          },
          {
            id: "p3",
            enunciado: "¿Para qué se usa principalmente el alfabeto manual?",
            opciones: [
              "Para reemplazar todas las palabras señaladas en la conversación.",
              "Para nombres propios, apellidos, lugares y palabras sin una señal reconocida.",
              "Para escribir frases completas porque la LSC no tiene vocabulario propio.",
              "Únicamente para deletrear el abecedario completo en cada saludo."
            ],
            correcta: 1
          },
          {
            id: "p4",
            enunciado: "¿Cuál es una secuencia natural para presentarte en LSC?",
            opciones: [
              "Ocupación → lugar de origen → nombre completo.",
              "Número de documento → dirección → ocupación.",
              "Nombre → lugar de origen → ocupación o actividad.",
              "Únicamente deletrear tu nombre sin más información."
            ],
            correcta: 2
          },
          {
            id: "p5",
            enunciado: "¿Qué vocabulario usarías para saludar por la mañana?",
            opciones: [
              "Buenas noches.",
              "Buenos días.",
              "Adiós.",
              "Hasta luego."
            ],
            correcta: 1
          },
          {
            id: "p6",
            enunciado: "Quieres responder que tienes 12 años. ¿Qué haces en LSC?",
            opciones: [
              "Señas el número 12 como parte de la respuesta.",
              "Deletreo \"doce\" con el alfabeto manual siempre.",
              "Escribo la respuesta en papel.",
              "Señalo el número 1 y luego el 2 sin ninguna pausa."
            ],
            correcta: 0
          },
          {
            id: "p7",
            enunciado: "En la lección de familia, ¿qué término se refiere a una persona cercana que NO es familiar?",
            opciones: [
              "Abuelo",
              "Hermana",
              "Hijo",
              "Amigo"
            ],
            correcta: 3
          },
          {
            id: "p8",
            enunciado: "¿Cuál es un ejemplo correcto de descripción usando colores en LSC?",
            opciones: [
              "«Mochila, color azul, grande» (objeto + color + tamaño).",
              "Repetir «azul, azul, azul» en voz alta varias veces.",
              "Deletrear \"azul\" porque los colores no tienen señal propia.",
              "Señalar el color en la ropa de la otra persona sin decir nada más."
            ],
            correcta: 0
          },
          {
            id: "p9",
            enunciado: "Durante una conversación no entiendes una señal. ¿Qué es lo más apropiado?",
            opciones: [
              "Abandonar la conversación sin decir nada.",
              "Reír y fingir que entendiste.",
              "Señalar «no entiendo» y pedir «otra vez».",
              "Deletrear toda tu frase con el alfabeto manual."
            ],
            correcta: 2
          },
          {
            id: "p10",
            enunciado: "Según la lección 1, ¿por qué es importante aprender LSC?",
            opciones: [
              "Para poder hablar con personas sordas sin depender de intermediarios y promover la inclusión.",
              "Para tener un código secreto con amigos.",
              "Porque es obligatorio en todos los trabajos colombianos.",
              "Para reemplazar el español en la vida cotidiana."
            ],
            correcta: 0
          }
        ]
      }
    },

    /* ======================================================================
       MÓDULOS FUTUROS (estructura lista, contenido por agregar)
       ======================================================================*/
    {
      id: "basic-2",
      titulo: "Basic 2",
      subtitulo: "Conversación cotidiana",
      estado: "proximo",
      imagen: URL_IMAGEN_MODULO_BASIC_2,
      descripcion:
        "Da un paso hacia conversaciones más largas: preguntas frecuentes, lugares, comida " +
        "y horarios. Este módulo estará disponible próximamente.",
      lecciones: [
        { id: "b2-l1", numero: 1, titulo: "Presentación del módulo", descripcion: "Objetivos y contenido de Basic 2.", estado: "proximo" },
        { id: "b2-l2", numero: 2, titulo: "Preguntas frecuentes", descripcion: "Preguntar y responder sobre lugares, horarios y actividades.", estado: "proximo" },
        { id: "b2-l3", numero: 3, titulo: "Lugares y direcciones", descripcion: "Orientarse y describir lugares en la ciudad.", estado: "proximo" },
        { id: "b2-l4", numero: 4, titulo: "Comida y bebida", descripcion: "Vocabulario de alimentos y pedidos sencillos.", estado: "proximo" },
        { id: "b2-l5", numero: 5, titulo: "Evaluación de Basic 2", descripcion: "Evaluación del módulo (próximamente).", estado: "proximo" }
      ],
      evaluacion: null
    },
    {
      id: "basic-3",
      titulo: "Basic 3",
      subtitulo: "Historias y experiencias",
      estado: "proximo",
      imagen: URL_IMAGEN_MODULO_BASIC_3,
      descripcion:
        "Cuenta experiencias, describe personas y habla del pasado y del futuro. Contenido " +
        "en preparación.",
      lecciones: [
        { id: "b3-l1", numero: 1, titulo: "Presentación del módulo", descripcion: "Objetivos y contenido de Basic 3.", estado: "proximo" },
        { id: "b3-l2", numero: 2, titulo: "Describir personas", descripcion: "Apariencia, características y cualidades.", estado: "proximo" },
        { id: "b3-l3", numero: 3, titulo: "Tiempo: pasado y futuro", descripcion: "Marcas temporales en LSC.", estado: "proximo" },
        { id: "b3-l4", numero: 4, titulo: "Contar una historia", descripcion: "Estructura narrativa básica en LSC.", estado: "proximo" },
        { id: "b3-l5", numero: 5, titulo: "Evaluación de Basic 3", descripcion: "Evaluación del módulo (próximamente).", estado: "proximo" }
      ],
      evaluacion: null
    },
    {
      id: "basic-4",
      titulo: "Basic 4",
      subtitulo: "LSC en la comunidad",
      estado: "proximo",
      imagen: URL_IMAGEN_MODULO_BASIC_4,
      descripcion:
        "Aplica lo aprendido en situaciones reales: escuela, trabajo, servicios y cultura " +
        "sorda. Contenido en preparación.",
      lecciones: [
        { id: "b4-l1", numero: 1, titulo: "Presentación del módulo", descripcion: "Objetivos y contenido de Basic 4.", estado: "proximo" },
        { id: "b4-l2", numero: 2, titulo: "LSC en la escuela", descripcion: "Vocabulario académico y situaciones de clase.", estado: "proximo" },
        { id: "b4-l3", numero: 3, titulo: "LSC en el trabajo", descripcion: "Entrevistas, reuniones y atención al público.", estado: "proximo" },
        { id: "b4-l4", numero: 4, titulo: "Cultura sorda colombiana", descripcion: "Identidad, historia y comunidad sorda.", estado: "proximo" },
        { id: "b4-l5", numero: 5, titulo: "Evaluación de Basic 4", descripcion: "Evaluación del módulo (próximamente).", estado: "proximo" }
      ],
      evaluacion: null
    }
  ]
};

/* ============================================================================
   FUNCIONES AUXILIARES SOBRE LOS DATOS
   ============================================================================
*/
function obtenerModulo(idModulo) {
  return CURSO.modulos.find(m => m.id === idModulo) || null;
}

function obtenerLeccion(idModulo, idLeccion) {
  const modulo = obtenerModulo(idModulo);
  if (!modulo) return null;
  return modulo.lecciones.find(l => l.id === idLeccion) || null;
}

/* Devuelve la siguiente lección disponible de Basic 1 (salta las que no tienen contenido) */
function siguienteLeccion(idModulo, idLeccion) {
  const modulo = obtenerModulo(idModulo);
  if (!modulo) return null;
  const indice = modulo.lecciones.findIndex(l => l.id === idLeccion);
  if (indice === -1 || indice === modulo.lecciones.length - 1) return null;
  return modulo.lecciones[indice + 1];
}

function leccionAnterior(idModulo, idLeccion) {
  const modulo = obtenerModulo(idModulo);
  if (!modulo) return null;
  const indice = modulo.lecciones.findIndex(l => l.id === idLeccion);
  if (indice <= 0) return null;
  return modulo.lecciones[indice - 1];
}
