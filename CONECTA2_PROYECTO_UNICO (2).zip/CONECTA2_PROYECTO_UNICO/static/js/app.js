/* ============================================================================
   LÓGICA DE LA PLATAFORMA · SeñasColombia
   ----------------------------------------------------------------------------
   Flujo de la aplicación (SPA sin servidor):
     1. Autenticación real mediante Flask y MySQL.
     2. Dashboard con progreso general y módulos.
     3. Vista de módulo con sus lecciones.
     4. Pantalla de estudio de cada lección (contenido + actividad).
     5. Evaluación final con cálculo de nota.
     6. Finalización del módulo y persistencia del progreso (localStorage).

   Nota sobre persistencia: localStorage guarda el avance solo en este
   navegador. No es almacenamiento seguro ni se sincroniza entre dispositivos.
   Para producción se recomienda una base de datos con usuarios reales.
   ============================================================================
*/

/* =============================== ESTADO ================================= */
const CLAVE_SESION = "lsc_sesion";
const CLAVE_PROGRESO = "lsc_progreso_";

const estado = {
  usuario: null,        // usuario activo de la sesión
  vista: "bienvenida",  // bienvenida | dashboard | modulo | leccion | evaluacion | resultado | completado
  moduloActual: null,   // id del módulo abierto
  leccionActual: null,  // id de la lección abierta
  progreso: null,       // progreso del usuario activo
  evaluacion: {
    indice: 0,          // índice de la pregunta actual
    respuestas: {},     // { idPregunta: indiceOpcion }
    finalizada: false,
    nota: null
  }
};

/* ========================= UTILIDADES GENÉRICAS ========================= */
const $ = (selector) => document.querySelector(selector);

function escapar(texto) {
  return String(texto ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function esMarcador(url) {
  // Un "marcador" es cualquier valor vacío o que empiece con AQUI_DEBES_PONER...
  if (!url) return true;
  return typeof url === "string" && url.trim().startsWith("AQUI_DEBES_PONER");
}

/* Renderiza una imagen o video; si no hay URL configurada, muestra un
   espacio de reemplazo amable sin romper el diseño. */
function renderMedia(url, alt, opciones = {}) {
  const { tipo = "imagen", leyenda = "", claseContenedor = "", icono = "🖼️" } = opciones;

  if (esMarcador(url)) {
    return `
      <div class="media-contenedor ${claseContenedor}">
        <div class="media-placeholder" role="img" aria-label="${escapar(alt || "Imagen pendiente de agregar")}">
          <span class="ph-icono" aria-hidden="true">${icono}</span>
          <span class="ph-texto">${tipo === "video" ? "Video pendiente de agregar" : "Imagen pendiente de agregar"}</span>
          <span class="ph-ayuda">Configura la URL en <code>js/config.js</code> o <code>js/data.js</code> para reemplazar este espacio.</span>
        </div>
        ${leyenda ? `<p class="media-leyenda">${escapar(leyenda)}</p>` : ""}
      </div>`;
  }

  if (tipo === "video") {
    // Soporta enlaces de video (YouTube/Vimeo embed) o archivos de video
    const esEmbed = /(youtube\.com|youtu\.be|vimeo\.com)/i.test(url);
    const contenido = esEmbed
      ? `<iframe src="${escapar(url)}" title="${escapar(alt || "Video demostrativo")}" allowfullscreen loading="lazy"></iframe>`
      : `<video controls preload="metadata" aria-label="${escapar(alt || "Video demostrativo")}">
           <source src="${escapar(url)}" />
           Tu navegador no puede reproducir este video.
         </video>`;
    return `
      <div class="media-contenedor media-video ${claseContenedor}">
        ${contenido}
        ${leyenda ? `<p class="media-leyenda">${escapar(leyenda)}</p>` : ""}
      </div>`;
  }

  return `
    <div class="media-contenedor ${claseContenedor}">
      <img src="${escapar(url)}" alt="${escapar(alt || "")}" loading="lazy" />
      ${leyenda ? `<p class="media-leyenda">${escapar(leyenda)}</p>` : ""}
    </div>`;
}

/* ====================== PROGRESO (localStorage) ========================= */
function cargarProgreso(usuario) {
  try {
    const crudo = localStorage.getItem(CLAVE_PROGRESO + usuario);
    if (crudo) return JSON.parse(crudo);
  } catch (e) {
    console.warn("No se pudo leer el progreso guardado:", e);
  }
  // Estructura por defecto del progreso de un usuario
  return {
    usuario,
    leccionesCompletadas: [],   // ids de lecciones completadas
    ultimaLeccion: null,        // { modulo, leccion }
    moduloCompletado: {},       // { "basic-1": { nota, fecha } }
    ultimoAcceso: null
  };
}

async function guardarProgreso() {
  if (!estado.progreso) return;
  estado.progreso.ultimoAcceso = new Date().toISOString();
  try {
    localStorage.setItem(CLAVE_PROGRESO + (estado.emailUsuario || estado.usuario), JSON.stringify(estado.progreso));
    const response = await fetch("/api/progress", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ progress: estado.progreso }) });
    if (!response.ok) console.warn("El servidor no pudo guardar el progreso en MySQL.");
  } catch (e) { console.warn("No se pudo sincronizar el progreso:", e); }
}

function leccionCompletada(idLeccion) {
  return estado.progreso.leccionesCompletadas.includes(idLeccion);
}

function marcarLeccionCompletada(idLeccion) {
  if (!leccionCompletada(idLeccion)) {
    estado.progreso.leccionesCompletadas.push(idLeccion);
  }
  estado.progreso.ultimaLeccion = { modulo: estado.moduloActual, leccion: idLeccion };
  guardarProgreso();
}

/* Progreso general del curso: lecciones completadas de Basic 1 sobre el total */
function calcularProgresoGeneral() {
  const modulo = obtenerModulo(CURSO.nivelInicial);
  const total = modulo.lecciones.length;
  const completadas = modulo.lecciones.filter(l => leccionCompletada(l.id)).length;
  const moduloOk = estado.progreso.moduloCompletado[modulo.id] ? 1 : 0;
  const totalTareas = total + 1; // +1 = evaluación/módulo
  const hechas = completadas + moduloOk;
  return {
    completadas,
    total,
    porcentaje: Math.round((hechas / totalTareas) * 100),
    moduloCompletado: moduloOk === 1
  };
}

/* ======================= SESIÓN (Flask + MySQL) ========================= */
async function iniciarSesion(usuario) {
  estado.usuario = usuario.name || usuario.nombre || usuario.email;
  estado.emailUsuario = usuario.email || usuario.correo || estado.usuario;
  estado.progreso = cargarProgreso(estado.emailUsuario);
  try {
    const response = await fetch("/api/progress");
    if (response.ok) {
      const data = await response.json();
      if (data.progress && typeof data.progress === "object") estado.progreso = data.progress;
    }
  } catch (e) { console.warn("No se pudo recuperar el progreso remoto.", e); }
  sessionStorage.setItem(CLAVE_SESION, "authenticated");
  $("#usuario-activo").textContent = estado.usuario;
  mostrarVista("dashboard");
}

function cerrarSesion() {
  estado.usuario = null;
  estado.emailUsuario = null;
  estado.progreso = null;
  estado.moduloActual = null;
  estado.leccionActual = null;
  sessionStorage.removeItem(CLAVE_SESION);
  fetch("/api/logout", { method: "POST" }).catch(() => {});
  $("#form-login").reset();
  mostrarVista("bienvenida");
}

async function restaurarSesion() {
  try {
    const response = await fetch("/api/session");
    const data = await response.json();
    if (data.authenticated && data.user) { await iniciarSesion(data.user); return true; }
  } catch (e) { console.warn("No se pudo comprobar la sesión del servidor.", e); }
  sessionStorage.removeItem(CLAVE_SESION);
  return false;
}

/* ===================== NAVEGACIÓN ENTRE VISTAS ========================== */
function mostrarVista(vista, opciones = {}) {
  estado.vista = vista;

  // Mostrar/ocultar las dos vistas raíz
  const esApp = vista !== "bienvenida";
  $("#vista-bienvenida").hidden = esApp;
  $("#vista-app").hidden = !esApp;

  if (!esApp) {
    window.scrollTo({ top: 0 });
    return;
  }

  // Ocultar todas las vistas internas y mostrar la solicitada
  ["interna-dashboard", "interna-modulo", "interna-leccion", "interna-evaluacion", "interna-resultado", "interna-diccionario", "interna-practica", "interna-admin"]
    .forEach(id => { const nodo = $("#" + id); if (nodo) nodo.hidden = true; });

  switch (vista) {
    case "dashboard":  renderDashboard(); break;
    case "modulo":     renderModulo(opzioniModulo(opciones)); break;
    case "leccion":    renderLeccion(opciones.idLeccion); break;
    case "evaluacion": renderEvaluacion(); break;
    case "resultado":  renderResultado(); break;
    case "diccionario": renderDiccionario(); break;
    case "practica": renderPractica(); break;
  }

  renderMenuLateral();
  window.scrollTo({ top: 0, behavior: "smooth" });
  // Enfocar el área principal para lectores de pantalla y teclado
  $("#area-contenido").focus({ preventScroll: true });
}

/* Pequeño normalizador para la opción de módulo */
function opzioniModulo(opciones) {
  return opciones.idModulo || estado.moduloActual;
}

/* =================== MENÚ LATERAL DE MÓDULOS ============================ */
function renderMenuLateral() {
  const progreso = calcularProgresoGeneral();
  const lista = $("#lista-modulos-lateral");

  lista.innerHTML = CURSO.modulos.map(modulo => {
    const activo = modulo.id === estado.moduloActual;
    let estadoTexto = "";
    let badge = "";
    if (modulo.estado === "proximo") {
      estadoTexto = "Próximamente";
      badge = `<span class="estado-badge badge-proximo">Próximamente</span>`;
    } else if (progreso.moduloCompletado) {
      estadoTexto = "Completado";
      badge = `<span class="estado-badge badge-completado">Completado</span>`;
    } else {
      estadoTexto = `Progreso: ${progreso.completadas}/${progreso.total} lecciones`;
      badge = `<span class="estado-badge badge-activo">Activo</span>`;
    }
    return `
      <li>
        <button class="item-modulo-btn ${activo ? "activo" : ""}" data-modulo="${modulo.id}"
                ${activo ? 'aria-current="page"' : ""}>
          <span class="mod-emoji" aria-hidden="true">${modulo.estado === "proximo" ? "🔒" : (progreso.moduloCompletado ? "✅" : "📘")}</span>
          <span>
            <span class="mod-nombre">${escapar(modulo.titulo)}</span>
            <span class="mod-estado">${escapar(estadoTexto)}</span>
          </span>
          ${badge}
        </button>
      </li>`;
  }).join("");

  // Progreso del panel
  $("#progreso-lateral-pct").textContent = progreso.porcentaje + " %";
  const barra = $("#barra-progreso-lateral");
  barra.setAttribute("aria-valuenow", progreso.porcentaje);
  barra.querySelector(".barra-progreso-relleno").style.width = progreso.porcentaje + "%";
}

/* ============================ DASHBOARD ================================= */
function renderDashboard() {
  const progreso = calcularProgresoGeneral();
  const moduloInicial = obtenerModulo(CURSO.nivelInicial);
  const moduloCompletadoInfo = estado.progreso.moduloCompletado[moduloInicial.id];

  // Última lección visitada
  let ultimaLeccionHtml = "Aún no has comenzado";
  if (estado.progreso.ultimaLeccion) {
    const ult = estado.progreso.ultimaLeccion;
    const mod = obtenerModulo(ult.modulo);
    const lec = mod ? mod.lecciones.find(l => l.id === ult.leccion) : null;
    if (mod && lec) {
      ultimaLeccionHtml = `${escapar(mod.titulo)} · Lección ${lec.numero}: ${escapar(lec.titulo)}`;
    }
  }

  // Mensaje de "continuar aprendiendo"
  let continuarId = null;
  const pendiente = moduloInicial.lecciones.find(l => !leccionCompletada(l.id));
  if (pendiente) continuarId = pendiente.id;

  const tarjetasModulos = CURSO.modulos.map(modulo => {
    const esActivo = modulo.estado !== "proximo";
    const estadoBadge = modulo.estado === "proximo"
      ? `<span class="estado-badge badge-proximo">Próximamente</span>`
      : (progreso.moduloCompletado
          ? `<span class="estado-badge badge-completado">Completado</span>`
          : `<span class="estado-badge badge-activo">Disponible</span>`);

    const boton = modulo.estado === "proximo"
      ? `<button class="btn btn-secundario btn-pequeno" data-ver-proximo="${modulo.id}">Ver contenido</button>`
      : (progreso.moduloCompletado
          ? `<button class="btn btn-destacado btn-pequeno" data-modulo="${modulo.id}">Repasar módulo</button>`
          : `<button class="btn btn-primario btn-pequeno" data-modulo="${modulo.id}">${continuarId === moduloInicial.lecciones[0].id ? "Comenzar curso" : "Continuar"}</button>`);

    const media = renderMedia(modulo.imagen, `Imagen de presentación del módulo ${modulo.titulo}`, {
      claseContenedor: "modulo-media", icono: "📘"
    });

    return `
      <article class="tarjeta-modulo">
        ${media}
        <div class="modulo-cuerpo">
          <span class="mod-subtitulo">${escapar(modulo.subtitulo)}</span>
          <h3>${escapar(modulo.titulo)}</h3>
          <p>${escapar(modulo.descripcion)}</p>
          <div class="modulo-pie">
            ${estadoBadge}
            ${boton}
          </div>
        </div>
      </article>`;
  }).join("");

  $("#interna-dashboard").innerHTML = `
    <section class="saludo-dashboard">
      <h1>¡Bienvenido a tu curso de LSC!</h1>
      <p>Hola, <strong>${escapar(estado.usuario)}</strong>. Sigue aprendiendo Lengua de Señas Colombiana paso a paso.</p>
    </section>

    <section class="datos-dashboard" aria-label="Resumen de tu progreso">
      <div class="dato-tarjeta amarillo">
        <span class="dato-label">Progreso general</span>
        <span class="dato-valor">${progreso.porcentaje} %</span>
        <div class="barra-progreso" role="progressbar" aria-label="Progreso general"
             aria-valuemin="0" aria-valuemax="100" aria-valuenow="${progreso.porcentaje}">
          <span class="barra-progreso-relleno" style="width:${progreso.porcentaje}%"></span>
        </div>
      </div>
      <div class="dato-tarjeta">
        <span class="dato-label">Módulos completados</span>
        <span class="dato-valor">${Object.keys(estado.progreso.moduloCompletado).length} / ${CURSO.modulos.length}</span>
        <span class="dato-extra">${moduloCompletadoInfo ? `¡${escapar(moduloInicial.titulo)} completado!` : "Completa Basic 1 para avanzar."}</span>
      </div>
      <div class="dato-tarjeta">
        <span class="dato-label">Lecciones completadas</span>
        <span class="dato-valor">${progreso.completadas} / ${progreso.total}</span>
        <span class="dato-extra">Módulo ${escapar(moduloInicial.titulo)}</span>
      </div>
      <div class="dato-tarjeta">
        <span class="dato-label">Última lección visitada</span>
        <span class="dato-valor" style="font-size:1.05rem">${ultimaLeccionHtml}</span>
      </div>
    </section>

    <section class="tarjeta" aria-label="Continuar aprendiendo">
      <h2>Continuar aprendiendo</h2>
      ${moduloCompletadoInfo
        ? `<p>¡Felicidades! Completaste ${escapar(moduloInicial.titulo)} con una calificación de ${moduloCompletadoInfo.nota} %. Puedes repasar las lecciones o esperar el próximo módulo.</p>
           <div class="grupo-botones">
             <button class="btn btn-secundario" data-modulo="basic-1">Repasar lecciones</button>
           </div>`
        : (continuarId
            ? `<p>Retoma donde te quedaste: <strong>${escapar(ultimaLeccionHtml)}</strong></p>
               <div class="grupo-botones">
                 <button class="btn btn-destacado" data-continuar="${continuarId}">Continuar aprendiendo</button>
                 <button class="btn btn-secundario" data-modulo="basic-1">Ver todas las lecciones</button>
               </div>`
            : `<p>Has estudiado todas las lecciones. ¡Es el momento de presentar la evaluación final!</p>
               <button class="btn btn-destacado" data-modulo="basic-1">Ir a la evaluación</button>`)}
    </section>

    <section aria-label="Módulos del curso">
      <div class="encabezado-seccion">
        <h2>Módulos del curso</h2>
        <p>Basic 1 está disponible. Los niveles siguientes se habilitarán próximamente.</p>
      </div>
      <div class="rejilla-modulos">${tarjetasModulos}</div>
    </section>`;

  $("#interna-dashboard").hidden = false;
  estado.moduloActual = null;
}

/* ============================== MÓDULO ================================== */
function renderModulo(idModulo) {
  const modulo = obtenerModulo(idModulo);
  if (!modulo) { mostrarVista("dashboard"); return; }

  estado.moduloActual = idModulo;
  const progreso = calcularProgresoGeneral();
  const moduloCompletado = !!estado.progreso.moduloCompletado[idModulo];
  const esFuturo = modulo.estado === "proximo";

  const leccionesHtml = modulo.lecciones.map(leccion => {
    // Las lecciones de módulos futuros tienen estado "proximo" y sin contenido
    const futura = leccion.estado === "proximo";
    const completada = leccionCompletada(leccion.id);

    let badge;
    if (futura) badge = `<span class="estado-badge badge-proximo">Próximamente</span>`;
    else if (completada) badge = `<span class="estado-badge badge-completado">Completada</span>`;
    else if (estado.progreso.ultimaLeccion && estado.progreso.ultimaLeccion.leccion === leccion.id)
      badge = `<span class="estado-badge badge-amarillo">En progreso</span>`;
    else badge = `<span class="estado-badge badge-proximo">Pendiente</span>`;

    const media = renderMedia(leccion.imagen, `Imagen de apoyo de la lección ${leccion.numero}: ${leccion.titulo}`, {
      claseContenedor: "leccion-media", icono: "🖼️"
    });

    const boton = futura
      ? `<button class="btn btn-secundario btn-pequeno" disabled>Próximamente</button>`
      : (completada
          ? `<button class="btn btn-secundario btn-pequeno" data-leccion="${leccion.id}">Repasar</button>`
          : `<button class="btn btn-primario btn-pequeno" data-leccion="${leccion.id}">Comenzar lección</button>`);

    return `
      <article class="tarjeta-leccion ${completada ? "completada" : ""}">
        ${media}
        <div class="leccion-info">
          <span class="leccion-numero">Lección ${leccion.numero}</span>
          <h3>${escapar(leccion.titulo)}</h3>
          <p>${escapar(leccion.descripcion || "")}</p>
        </div>
        <div class="leccion-acciones">
          ${badge}
          ${boton}
        </div>
      </article>`;
  }).join("");

  // Bloque de evaluación final (solo si el módulo tiene evaluación)
  const leccionesPendientes = modulo.lecciones.filter(l => l.estado !== "proximo" && !leccionCompletada(l.id)).length;
  let evaluacionHtml = "";
  if (modulo.evaluacion) {
    const habilitada = leccionesPendientes === 0;
    evaluacionHtml = `
      <section class="tarjeta" aria-label="Evaluación final">
        <div class="encabezado-seccion">
          <h2>Evaluación final</h2>
          <p>${escapar(modulo.evaluacion.descripcion)}</p>
        </div>
        ${habilitada
          ? `<button class="btn btn-destacado btn-grande" data-evaluacion="1">Iniciar evaluación (${modulo.evaluacion.preguntas.length} preguntas)</button>`
          : `<div class="aviso-bloqueo">
               <p><strong>Evaluación bloqueada.</strong> Completa todas las lecciones para acceder. Te faltan <strong>${leccionesPendientes}</strong> lección(es).</p>
             </div>`}
        ${moduloCompletado
          ? `<p style="margin-top:1rem"><span class="estado-badge badge-completado">Módulo completado con ${estado.progreso.moduloCompletado[idModulo].nota} %</span></p>`
          : ""}
      </section>`;
  }

  const mediaModulo = renderMedia(modulo.imagen, `Imagen de presentación del módulo ${modulo.titulo}`, {
    claseContenedor: "modulo-media", icono: "📘"
  });

  $("#interna-modulo").innerHTML = `
    <nav class="migas" aria-label="Ruta de navegación">
      <button data-dashboard="1">Panel principal</button> <span aria-hidden="true">›</span> <span>${escapar(modulo.titulo)}</span>
    </nav>

    <section class="tarjeta">
      ${esFuturo ? "" : mediaModulo}
      <div class="encabezado-seccion" style="margin-top:${esFuturo ? "0" : "1.2rem"}">
        <p>
          <span class="estado-badge ${esFuturo ? "badge-proximo" : (moduloCompletado ? "badge-completado" : "badge-activo")}">
            ${esFuturo ? "Próximamente" : (moduloCompletado ? "Completado" : "Disponible")}
          </span>
        </p>
        <h1>${escapar(modulo.titulo)} — ${escapar(modulo.subtitulo)}</h1>
        <p>${escapar(modulo.descripcion)}</p>
      </div>
      ${esFuturo
        ? `<div class="aviso-bloqueo"><p><strong>Este módulo está en preparación.</strong> Puedes ver la lista de lecciones previstas, pero su contenido se habilitará en una futura versión de la plataforma.</p></div>`
        : `<div style="margin-top:1rem">
             <p><strong>Progreso del módulo:</strong> ${progreso.completadas} de ${progreso.total} lecciones completadas.</p>
             <div class="barra-progreso" role="progressbar" aria-label="Progreso del módulo"
                  aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round((progreso.completadas / progreso.total) * 100)}">
               <span class="barra-progreso-relleno" style="width:${Math.round((progreso.completadas / progreso.total) * 100)}%"></span>
             </div>
           </div>`}
    </section>

    <section aria-label="Lecciones del módulo">
      <div class="encabezado-seccion">
        <h2>Lecciones</h2>
      </div>
      <div class="lista-lecciones">${leccionesHtml}</div>
    </section>

    ${evaluacionHtml}`;

  $("#interna-modulo").hidden = false;
}

/* ============================= LECCIÓN ================================== */
function renderLeccion(idLeccion) {
  const modulo = obtenerModulo(estado.moduloActual) || obtenerModulo(CURSO.nivelInicial);
  const leccion = modulo.lecciones.find(l => l.id === idLeccion);
  if (!leccion || !leccion.contenido) { mostrarVista("modulo", { idModulo: modulo.id }); return; }

  estado.leccionActual = idLeccion;
  // Registrar como "última lección visitada" y guardar
  estado.progreso.ultimaLeccion = { modulo: modulo.id, leccion: idLeccion };
  guardarProgreso();

  /* --- Renderizar bloques de contenido --- */
  const bloquesHtml = leccion.contenido.map(bloque => {
    switch (bloque.tipo) {
      case "subtitulo":
        return `<h2>${escapar(bloque.texto)}</h2>`;
      case "texto":
        return `<div class="bloque-contenido"><p>${bloque.html}</p></div>`;
      case "lista":
        return `<div class="bloque-contenido"><ul>${bloque.items.map(i => `<li>${i}</li>`).join("")}</ul></div>`;
      case "nota":
        return `<div class="nota-importante">${bloque.html}</div>`;
      case "media":
        return renderMedia(bloque.url, bloque.alt, { tipo: /video|gif/i.test(bloque.url || "") ? "video" : "imagen", leyenda: bloque.leyenda || "", icono: "🎞️" });
      case "vocabulario":
        return `<div class="tabla-vocabulario">${bloque.items.map(item => `
          <div class="vocab-item">
            <span class="vocab-termino">${escapar(item.termino)}</span><br>
            <span class="vocab-sena">${escapar(item.seña || "")}</span>
            <p class="vocab-detalle">${escapar(item.detalle || "")}</p>
          </div>`).join("")}</div>`;
      default:
        return "";
    }
  }).join("");

  /* --- Rejillas especiales: alfabeto, números, colores --- */
  let rejillaEspecial = "";
  if (leccion.alfabeto) {
    rejillaEspecial = `
      <h2>Cada letra del alfabeto</h2>
      <p>Revisa la configuración de cada letra con el material visual validado. Para agregar la imagen o el video, reemplaza el campo <code>media</code> de cada letra en <code>js/data.js</code>.</p>
      <div class="rejilla-alfabeto">
        ${leccion.alfabeto.map(item => `
          <div class="celda-media">
            <div class="media-placeholder" role="img" aria-label="Imagen o video pendiente de la letra ${escapar(item.letra)}">
              <span class="ph-icono" aria-hidden="true">✋</span>
              <span class="ph-texto">${esMarcador(item.media) ? "Pendiente" : "Disponible"}</span>
            </div>
            <span class="celda-label">${escapar(item.letra)}</span>
          </div>`).join("")}
      </div>`;
  }
  if (leccion.numeros) {
    rejillaEspecial = `
      <h2>Referencia visual de los números</h2>
      <div class="rejilla-alfabeto">
        ${leccion.numeros.map(item => `
          <div class="celda-media">
            <div class="media-placeholder" role="img" aria-label="Imagen o video pendiente del número ${escapar(item.numero)}">
              <span class="ph-icono" aria-hidden="true">🔢</span>
              <span class="ph-texto">${esMarcador(item.media) ? "Pendiente" : "Disponible"}</span>
            </div>
            <span class="celda-label">${escapar(item.numero)}</span>
          </div>`).join("")}
      </div>`;
  }
  if (leccion.colores) {
    rejillaEspecial = `
      <h2>Referencia visual de los colores</h2>
      <div class="rejilla-colores">
        ${leccion.colores.map(item => `
          <div class="celda-color">
            <div class="muestra-color" style="background:${escapar(item.hex)}" aria-hidden="true"></div>
            <span class="celda-label">${escapar(item.color)}</span>
            <div class="media-placeholder" style="min-height:60px;border:0;border-radius:0" role="img" aria-label="Seña de color ${escapar(item.color)} pendiente">
              <span class="ph-texto">${esMarcador(item.media) ? "Seña pendiente" : "Disponible"}</span>
            </div>
          </div>`).join("")}
      </div>`;
  }

  /* --- Video principal de la lección --- */
  const videoHtml = renderMedia(leccion.video, `Video demostrativo de la lección ${leccion.numero}: ${leccion.titulo}`, {
    tipo: "video", icono: "🎞️",
    leyenda: "Espacio para video o GIF demostrativo de la lección."
  });

  /* --- Navegación anterior/siguiente --- */
  const anterior = leccionAnterior(modulo.id, leccion.id);
  const siguiente = siguienteLeccion(modulo.id, leccion.id);
  const completada = leccionCompletada(leccion.id);

  $("#interna-leccion").innerHTML = `
    <nav class="migas" aria-label="Ruta de navegación">
      <button data-dashboard="1">Panel principal</button>
      <span aria-hidden="true">›</span>
      <button data-modulo="${modulo.id}">${escapar(modulo.titulo)}</button>
      <span aria-hidden="true">›</span>
      <span>Lección ${leccion.numero}</span>
    </nav>

    <article class="tarjeta">
      <header class="encabezado-seccion">
        <span class="estado-badge badge-activo">Lección ${leccion.numero} de ${modulo.lecciones.length}</span>
        <h1>${escapar(leccion.titulo)}</h1>
        <p>${escapar(leccion.descripcion)}</p>
      </header>

      <div class="leccion-objetivo">
        <strong>Objetivo de aprendizaje</strong>
        ${escapar(leccion.objetivo)}
      </div>

      <div class="nota-validacion">${escapar(NOTA_VALIDACION_LSC)}</div>

      ${bloquesHtml}
      ${rejillaEspecial}
      ${videoHtml}

      <!-- Actividad de refuerzo -->
      <section class="actividad" id="zona-actividad" aria-label="Actividad de refuerzo">
        <h3>Actividad de refuerzo</h3>
        <p class="actividad-subtitulo">Responde para comprobar lo aprendido antes de continuar.</p>
        <div id="actividad-contenedor"></div>
      </section>

      <!-- Navegación de la lección -->
      <div class="navegacion-leccion">
        <div class="grupo-botones">
          <button class="btn btn-secundario" data-modulo="${modulo.id}">← Volver al módulo</button>
          ${anterior ? `<button class="btn btn-secundario" data-leccion="${anterior.id}">← Lección anterior</button>` : ""}
        </div>
        <div class="grupo-botones">
          <button class="btn ${completada ? "btn-secundario" : "btn-destacado"}" id="btn-completar">
            ${completada ? "✓ Lección completada" : "Marcar como completada"}
          </button>
          ${siguiente ? `<button class="btn btn-primario" data-leccion="${siguiente.id}">Siguiente lección →</button>` : ""}
        </div>
      </div>
    </article>`;

  $("#interna-leccion").hidden = false;

  // Inicializar la actividad interactiva de la lección
  inicializarActividad(leccion.actividad);

  // Botón de completar lección
  const btnCompletar = $("#btn-completar");
  if (completada) {
    btnCompletar.disabled = true;
  } else {
    btnCompletar.addEventListener("click", () => {
      marcarLeccionCompletada(leccion.id);
      btnCompletar.textContent = "✓ Lección completada";
      btnCompletar.classList.remove("btn-destacado");
      btnCompletar.classList.add("btn-secundario");
      btnCompletar.disabled = true;

      // Feedback inmediato
      const zona = $("#zona-actividad");
      if (zona && !zona.querySelector(".retroalimentacion")) {
        zona.insertAdjacentHTML("beforeend",
          `<p class="retroalimentacion ok" role="status">¡Lección completada! Tu progreso se guardó en este navegador.</p>`);
      }
      renderMenuLateral();
    });
  }
}

/* ========================== ACTIVIDADES ================================= */
function inicializarActividad(actividad) {
  const contenedor = $("#actividad-contenedor");
  if (!contenedor) return;

  if (!actividad) {
    contenedor.innerHTML = `<p>No hay actividad configurada para esta lección.</p>`;
    return;
  }

  if (actividad.tipo === "opcion") renderActividadOpcion(contenedor, actividad);
  else if (actividad.tipo === "relacionar") renderActividadRelacionar(contenedor, actividad);
}

/* Actividad: una pregunta de opción múltiple */
function renderActividadOpcion(contenedor, actividad) {
  const letras = ["A", "B", "C", "D", "E", "F"];
  contenedor.innerHTML = `
    <p><strong>${escapar(actividad.pregunta)}</strong></p>
    <div class="opciones-lista" role="group" aria-label="Opciones de respuesta">
      ${actividad.opciones.map((op, i) => `
        <button class="opcion-btn" data-indice="${i}">
          <span class="letra-opcion" aria-hidden="true">${letras[i]}</span>
          <span>${escapar(op.texto)}</span>
        </button>`).join("")}
    </div>
    <div id="zona-retro" aria-live="polite"></div>`;

  contenedor.querySelectorAll(".opcion-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const indice = Number(btn.dataset.indice);
      const esCorrecta = actividad.opciones[indice].correcta === true;

      // Marcar visualmente la respuesta elegida
      contenedor.querySelectorAll(".opcion-btn").forEach(b => {
        b.classList.remove("seleccionada", "correcta", "incorrecta");
        b.disabled = true;
      });
      btn.classList.add(esCorrecta ? "correcta" : "incorrecta");

      // Resaltar también la correcta si el usuario falló
      if (!esCorrecta) {
        const idxCorrecta = actividad.opciones.findIndex(o => o.correcta === true);
        contenedor.querySelector(`.opcion-btn[data-indice="${idxCorrecta}"]`)?.classList.add("correcta");
      }

      const zona = $("#zona-retro");
      zona.innerHTML = esCorrecta
        ? `<p class="retroalimentacion ok" role="status">${escapar(actividad.retroalimentacionCorrecta)}</p>`
        : `<p class="retroalimentacion mal" role="status">${escapar(actividad.retroalimentacionIncorrecta)}</p>`;
    });
  });
}

/* Actividad: relacionar dos columnas */
function renderActividadRelacionar(contenedor, actividad) {
  // Mezclar la columna derecha de forma determinista pero no idéntica a la izquierda
  const derecha = actividad.pares.map((p, i) => ({ texto: p.derecha, indicePar: i }));
  // Intercalado sencillo para evitar el orden original
  for (let i = derecha.length - 1; i > 0; i--) {
    const j = (i * 3 + 1) % (i + 1);
    [derecha[i], derecha[j]] = [derecha[j], derecha[i]];
  }

  let seleccionIzq = null;
  let resueltas = 0;

  contenedor.innerHTML = `
    <p><strong>${escapar(actividad.tituloActividad || "Relaciona los elementos")}</strong></p>
    <p class="actividad-subtitulo">Selecciona un elemento de la izquierda y luego su pareja en la derecha.</p>
    <div class="relacionar-columnas">
      <div class="relacionar-lista" role="group" aria-label="Columna izquierda">
        ${actividad.pares.map((p, i) => `
          <button class="rel-item rel-izq" data-par="${i}">${escapar(p.izquierda)}</button>`).join("")}
      </div>
      <div class="relacionar-lista" role="group" aria-label="Columna derecha">
        ${derecha.map(d => `
          <button class="rel-item rel-der" data-par="${d.indicePar}">${escapar(d.texto)}</button>`).join("")}
      </div>
    </div>
    <div id="zona-retro" aria-live="polite"></div>`;

  const zona = $("#zona-retro");

  contenedor.querySelectorAll(".rel-izq").forEach(btn => {
    btn.addEventListener("click", () => {
      if (btn.classList.contains("resuelta")) return;
      contenedor.querySelectorAll(".rel-izq").forEach(b => b.classList.remove("seleccionada"));
      btn.classList.add("seleccionada");
      seleccionIzq = Number(btn.dataset.par);
    });
  });

  contenedor.querySelectorAll(".rel-der").forEach(btn => {
    btn.addEventListener("click", () => {
      if (btn.classList.contains("resuelta")) return;
      if (seleccionIzq === null) {
        zona.innerHTML = `<p class="retroalimentacion mal" role="status">Primero selecciona un elemento de la columna izquierda.</p>`;
        return;
      }
      const indicePar = Number(btn.dataset.par);
      const izqBtn = contenedor.querySelector(`.rel-izq[data-par="${seleccionIzq}"]`);

      if (indicePar === seleccionIzq) {
        // Pareja correcta
        btn.classList.add("resuelta");
        btn.disabled = true;
        izqBtn.classList.add("resuelta");
        izqBtn.disabled = true;
        izqBtn.classList.remove("seleccionada");
        seleccionIzq = null;
        resueltas++;
        if (resueltas === actividad.pares.length) {
          zona.innerHTML = `<p class="retroalimentacion ok" role="status">${escapar(actividad.retroalimentacionCorrecta)}</p>`;
        } else {
          zona.innerHTML = "";
        }
      } else {
        // Pareja incorrecta: feedback visual breve
        btn.classList.add("error");
        izqBtn?.classList.add("error");
        zona.innerHTML = `<p class="retroalimentacion mal" role="status">${escapar(actividad.retroalimentacionIncorrecta)}</p>`;
        setTimeout(() => {
          btn.classList.remove("error");
          contenedor.querySelectorAll(".rel-item").forEach(b => b.classList.remove("error"));
        }, 700);
      }
    });
  });
}

/* ============================ EVALUACIÓN ================================ */
function renderEvaluacion() {
  const modulo = obtenerModulo(estado.moduloActual) || obtenerModulo(CURSO.nivelInicial);
  const evaluacion = modulo.evaluacion;
  if (!evaluacion) { mostrarVista("modulo", { idModulo: modulo.id }); return; }

  const total = evaluacion.preguntas.length;
  const indice = estado.evaluacion.indice;
  const pregunta = evaluacion.preguntas[indice];
  const letras = ["A", "B", "C", "D", "E", "F"];
  const pct = Math.round(((indice + 1) / total) * 100);

  // Imagen de apoyo para la evaluación
  const ayudaHtml = renderMedia(evaluacion.imagenAyuda, "Imagen de apoyo de la evaluación", { icono: "📝" });

  $("#interna-evaluacion").innerHTML = `
    <nav class="migas" aria-label="Ruta de navegación">
      <button data-dashboard="1">Panel principal</button>
      <span aria-hidden="true">›</span>
      <button data-modulo="${modulo.id}">${escapar(modulo.titulo)}</button>
      <span aria-hidden="true">›</span>
      <span>Evaluación final</span>
    </nav>

    <article class="tarjeta">
      <header class="encabezado-seccion">
        <h1>${escapar(evaluacion.titulo)}</h1>
        <p>Marca una sola respuesta por pregunta. Necesitas ${PORCENTAJE_APROBACION} % para aprobar.</p>
      </header>

      <div class="evaluacion-progreso">
        <div class="barra-progreso" role="progressbar" aria-label="Avance de la evaluación"
             aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}">
          <span class="barra-progreso-relleno" style="width:${pct}%"></span>
        </div>
        <span class="eval-contador">Pregunta ${indice + 1} de ${total}</span>
      </div>

      <div id="zona-pregunta" aria-live="polite">
        <h2 class="pregunta-enunciado">${indice + 1}. ${escapar(pregunta.enunciado)}</h2>
        <div class="opciones-lista" role="group" aria-label="Opciones de respuesta">
          ${pregunta.opciones.map((op, i) => {
            const seleccionada = estado.evaluacion.respuestas[pregunta.id] === i;
            return `
              <button class="opcion-btn ${seleccionada ? "seleccionada" : ""}" data-opcion="${i}"
                      aria-pressed="${seleccionada}">
                <span class="letra-opcion" aria-hidden="true">${letras[i]}</span>
                <span>${escapar(op)}</span>
              </button>`;
          }).join("")}
        </div>
      </div>

      ${indice === total - 1 ? ayudaHtml : ""}

      <div class="navegacion-leccion">
        <div class="grupo-botones">
          <button class="btn btn-secundario" data-modulo="${modulo.id}">Salir de la evaluación</button>
          ${indice > 0 ? `<button class="btn btn-secundario" id="btn-pregunta-anterior">← Anterior</button>` : ""}
        </div>
        <div class="grupo-botones">
          ${indice < total - 1
            ? `<button class="btn btn-primario" id="btn-pregunta-siguiente">Siguiente →</button>`
            : `<button class="btn btn-destacado btn-grande" id="btn-finalizar">Finalizar evaluación</button>`}
        </div>
      </div>
    </article>`;

  $("#interna-evaluacion").hidden = false;

  // Seleccionar opción
  $("#interna-evaluacion").querySelectorAll(".opcion-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const i = Number(btn.dataset.opcion);
      estado.evaluacion.respuestas[pregunta.id] = i;
      $("#interna-evaluacion").querySelectorAll(".opcion-btn").forEach(b => {
        const sel = Number(b.dataset.opcion) === i;
        b.classList.toggle("seleccionada", sel);
        b.setAttribute("aria-pressed", sel);
      });
    });
  });

  // Navegación
  $("#btn-pregunta-anterior")?.addEventListener("click", () => {
    estado.evaluacion.indice = Math.max(0, indice - 1);
    renderEvaluacion();
  });

  const btnSiguiente = $("#btn-pregunta-siguiente");
  if (btnSiguiente) {
    btnSiguiente.addEventListener("click", () => {
      if (estado.evaluacion.respuestas[pregunta.id] === undefined) {
        alerta("Selecciona una respuesta antes de continuar.");
        return;
      }
      estado.evaluacion.indice = Math.min(total - 1, indice + 1);
      renderEvaluacion();
    });
  }

  $("#btn-finalizar")?.addEventListener("click", finalizarEvaluacion);
}

function alerta(mensaje) {
  // Mensaje accesible sin depender de alert() del navegador
  const zona = document.querySelector("#interna-evaluacion .navegacion-leccion");
  if (!zona) { window.alert(mensaje); return; }
  let aviso = zona.parentElement.querySelector(".retroalimentacion");
  if (!aviso) {
    aviso = document.createElement("p");
    aviso.className = "retroalimentacion mal";
    aviso.setAttribute("role", "alert");
    zona.parentElement.insertBefore(aviso, zona);
  }
  aviso.textContent = mensaje;
  aviso.scrollIntoView({ block: "nearest" });
}

function finalizarEvaluacion() {
  const modulo = obtenerModulo(estado.moduloActual) || obtenerModulo(CURSO.nivelInicial);
  const evaluacion = modulo.evaluacion;
  const total = evaluacion.preguntas.length;

  // Validar que todas las preguntas tengan respuesta
  const sinResponder = evaluacion.preguntas.filter(p => estado.evaluacion.respuestas[p.id] === undefined);
  if (sinResponder.length > 0) {
    // Ir a la primera pregunta sin responder
    estado.evaluacion.indice = evaluacion.preguntas.findIndex(p => estado.evaluacion.respuestas[p.id] === undefined);
    renderEvaluacion();
    alerta(`Faltan ${sinResponder.length} pregunta(s) por responder. Ve a la pregunta ${estado.evaluacion.indice + 1}.`);
    return;
  }

  // Calcular nota
  let aciertos = 0;
  evaluacion.preguntas.forEach(p => {
    if (estado.evaluacion.respuestas[p.id] === p.correcta) aciertos++;
  });
  const porcentaje = Math.round((aciertos / total) * 100);

  estado.evaluacion.finalizada = true;
  estado.evaluacion.nota = porcentaje;
  estado.evaluacion.aciertos = aciertos;
  estado.evaluacion.total = total;
  estado.evaluacion.aprobada = porcentaje >= PORCENTAJE_APROBACION;
  fetch("/api/result", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ module: modulo.titulo, score: porcentaje, correct: aciertos, total }) })
    .then(response => { if (!response.ok) console.warn("El resultado no se pudo guardar en MySQL."); })
    .catch(error => console.warn("No se pudo sincronizar el resultado de evaluación:", error));

  mostrarVista("resultado");
}

/* ======================= RESULTADO / FINALIZACIÓN ======================= */
function renderResultado() {
  const modulo = obtenerModulo(estado.moduloActual) || obtenerModulo(CURSO.nivelInicial);
  const { aciertos, total, nota, aprobada } = estado.evaluacion;

  // Guardar resultado (sin completar el módulo todavía: eso requiere pulsar "Completar módulo")
  const progreso = calcularProgresoGeneral();

  let mensaje;
  if (aprobada) {
    mensaje = `¡Felicidades, ${estado.usuario}! Aprobaste la evaluación de ${modulo.titulo} con ${aciertos} de ${total} respuestas correctas. Ya puedes completar el módulo.`;
  } else {
    mensaje = `Obtuviste ${aciertos} de ${total} respuestas correctas. ¡No te rindas! Repasa las lecciones que te resultaron más difíciles y vuelve a intentarlo: puedes lograrlo.`;
  }

  $("#interna-resultado").innerHTML = `
    <nav class="migas" aria-label="Ruta de navegación">
      <button data-dashboard="1">Panel principal</button>
      <span aria-hidden="true">›</span>
      <button data-modulo="${modulo.id}">${escapar(modulo.titulo)}</button>
      <span aria-hidden="true">›</span>
      <span>Resultado</span>
    </nav>

    <section class="tarjeta">
      <div class="resultado-caja">
        <span class="resultado-icono" aria-hidden="true">${aprobada ? "🎉" : "💪"}</span>
        <h1>${aprobada ? "¡Evaluación aprobada!" : "Casi lo logras"}</h1>
        <p class="resultado-puntos">${nota} %</p>
        <p class="resultado-porcentaje ${aprobada ? "ok" : "mal"}">${aciertos} de ${total} respuestas correctas</p>
        <p class="resultado-mensaje">${escapar(mensaje)}</p>

        <div class="grupo-botones" style="justify-content:center">
          <button class="btn btn-secundario" data-repetir="1">Repetir evaluación</button>
          <button class="btn btn-primario" data-modulo="${modulo.id}">Volver al contenido del módulo</button>
          ${aprobada ? `<button class="btn btn-destacado btn-grande" data-completar-modulo="${modulo.id}">Completar módulo</button>` : ""}
        </div>
      </div>
    </section>`;

  $("#interna-resultado").hidden = false;
}

function completarModulo(idModulo) {
  const modulo = obtenerModulo(idModulo);
  const nota = estado.evaluacion.nota;
  const ahora = new Date();

  estado.progreso.moduloCompletado[idModulo] = {
    nota,
    fecha: ahora.toISOString()
  };
  // Asegurar que todas las lecciones queden marcadas como completadas
  modulo.lecciones.forEach(l => {
    if (l.estado !== "proximo" && !leccionCompletada(l.id)) {
      estado.progreso.leccionesCompletadas.push(l.id);
    }
  });
  guardarProgreso();
  renderPantallaCompletado(idModulo, nota, ahora);
  renderMenuLateral();
}

function renderPantallaCompletado(idModulo, nota, fecha) {
  const modulo = obtenerModulo(idModulo);
  const indice = CURSO.modulos.findIndex(m => m.id === idModulo);
  const siguiente = CURSO.modulos[indice + 1] || null;
  const progreso = calcularProgresoGeneral();

  const fechaTexto = fecha.toLocaleDateString("es-CO", { day: "numeric", month: "long", year: "numeric" });

  $("#interna-resultado").innerHTML = `
    <section class="pantalla-completado">
      <span class="confeti" aria-hidden="true">🎓</span>
      <h1>¡Módulo completado!</h1>
      <p>Has finalizado <strong>${escapar(modulo.titulo)} — ${escapar(modulo.subtitulo)}</strong> con éxito.</p>

      <div class="datos-finalizacion">
        <div class="dato-tarjeta">
          <span class="dato-label">Módulo completado</span>
          <span class="dato-valor">${escapar(modulo.titulo)}</span>
        </div>
        <div class="dato-tarjeta">
          <span class="dato-label">Calificación obtenida</span>
          <span class="dato-valor">${nota} %</span>
        </div>
        <div class="dato-tarjeta">
          <span class="dato-label">Progreso del curso</span>
          <span class="dato-valor">${progreso.porcentaje} %</span>
        </div>
        <div class="dato-tarjeta">
          <span class="dato-label">Fecha de finalización</span>
          <span class="dato-valor" style="font-size:1.05rem">${escapar(fechaTexto)}</span>
        </div>
      </div>

      <div class="grupo-botones" style="justify-content:center">
        <button class="btn btn-destacado btn-grande" data-dashboard="1">Volver al panel principal</button>
      </div>
    </section>

    ${siguiente ? `
      <section class="siguiente-modulo-vista">
        <span class="estado-badge badge-proximo">Próximamente</span>
        <h2 style="margin-top:0.8rem">Siguiente módulo: ${escapar(siguiente.titulo)}</h2>
        <p style="color:var(--texto-suave);max-width:60ch;margin:0 auto 1.2rem">${escapar(siguiente.descripcion)}</p>
        <div class="rejilla-modulos" style="max-width:420px;margin:0 auto">
          <article class="tarjeta-modulo">
            ${renderMedia(siguiente.imagen, `Imagen de presentación del módulo ${siguiente.titulo}`, { claseContenedor: "modulo-media", icono: "📘" })}
            <div class="modulo-cuerpo">
              <span class="mod-subtitulo">${escapar(siguiente.subtitulo)}</span>
              <h3>${escapar(siguiente.titulo)}</h3>
              <p>${siguiente.lecciones.length} lecciones previstas</p>
              <div class="modulo-pie">
                <span class="estado-badge badge-proximo">Próximamente</span>
                <button class="btn btn-secundario btn-pequeno" data-modulo="${siguiente.id}">Ver contenido</button>
              </div>
            </div>
          </article>
        </div>
      </section>` : ""}`;

  $("#interna-resultado").hidden = false;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

/* ======================= DICCIONARIO LSC ================================ */
let elementosDiccionario = [];
async function renderDiccionario() {
  const vista = $("#interna-diccionario");
  vista.hidden = false;
  vista.innerHTML = `
    <nav class="migas"><button data-dashboard="1">Panel principal</button><span>›</span><span>Diccionario LSC</span></nav>
    <section class="tarjeta">
      <h1>Diccionario de Lengua de Señas Colombiana</h1>
      <p>Busca vocabulario por palabra, categoría o descripción. Las demostraciones visuales dependen de los recursos disponibles en la base de datos.</p>
      <div class="campo"><label for="buscar-diccionario">Buscar palabra</label><input id="buscar-diccionario" type="search" placeholder="Ej. saludo, familia, número…" /></div>
      <p id="estado-diccionario" role="status">Cargando vocabulario…</p>
      <div id="resultados-diccionario" class="rejilla-modulos"></div>
    </section>`;
  try {
    const response = await fetch('/api/dictionary');
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'No se pudo consultar la base de datos.');
    elementosDiccionario = Array.isArray(data.items) ? data.items : [];
    pintarDiccionario('');
    $("#buscar-diccionario").addEventListener('input', e => pintarDiccionario(e.target.value));
  } catch (error) {
    $("#estado-diccionario").textContent = `${error.message} Verifica que la base de datos tenga categorías y señas registradas.`;
  }
}
function pintarDiccionario(texto) {
  const q = String(texto || '').trim().toLocaleLowerCase('es');
  const filtrados = elementosDiccionario.filter(item => [item.palabra, item.categoria, item.definicion, item.descripcion_movimiento, item.ejemplo_uso]
    .some(v => String(v || '').toLocaleLowerCase('es').includes(q)));
  const estadoEl = $("#estado-diccionario");
  const lista = $("#resultados-diccionario");
  if (!lista || !estadoEl) return;
  estadoEl.textContent = filtrados.length ? `${filtrados.length} palabra(s) encontrada(s).` : 'No hay palabras que coincidan. Si el diccionario está vacío, agrega registros a la tabla sena de MySQL.';
  lista.innerHTML = filtrados.map(item => `
    <article class="tarjeta-modulo">
      <div class="modulo-cuerpo">
        <span class="mod-subtitulo">${escapar(item.categoria || 'Vocabulario LSC')}</span>
        <h3>${escapar(item.palabra || 'Palabra sin nombre')}</h3>
        <p>${escapar(item.definicion || item.descripcion_movimiento || 'Sin descripción registrada.')}</p>
        ${item.descripcion_movimiento && item.definicion ? `<p><strong>Descripción:</strong> ${escapar(item.descripcion_movimiento)}</p>` : ''}
        ${item.ejemplo_uso ? `<p><strong>Ejemplo:</strong> ${escapar(item.ejemplo_uso)}</p>` : ''}
        ${item.url_video ? `<div class="grupo-botones"><a class="btn btn-secundario" href="${escapar(item.url_video)}" target="_blank" rel="noopener noreferrer">Ver demostración</a></div>` : `<p class="acceso-nota">Demostración visual pendiente de agregar.</p>`}
      </div>
    </article>`).join('');
}

/* ======================= PRÁCTICA LIBRE ================================ */
let preguntaPractica = null;
function obtenerPreguntasPractica() {
  const modulo = obtenerModulo(CURSO.nivelInicial);
  return (modulo?.lecciones || []).filter(l => l.actividad?.tipo === 'opcion' && Array.isArray(l.actividad.opciones))
    .map(l => ({ titulo: l.titulo, ...l.actividad }));
}
function renderPractica() {
  const vista = $("#interna-practica");
  vista.hidden = false;
  const preguntas = obtenerPreguntasPractica();
  if (!preguntas.length) {
    vista.innerHTML = `<section class="tarjeta"><h1>Práctica libre</h1><p>Todavía no hay preguntas configuradas para practicar.</p><button class="btn btn-secundario" data-dashboard="1">Volver al panel</button></section>`;
    return;
  }
  preguntaPractica = preguntas[Math.floor(Math.random() * preguntas.length)];
  vista.innerHTML = `
    <nav class="migas"><button data-dashboard="1">Panel principal</button><span>›</span><span>Práctica libre</span></nav>
    <section class="tarjeta">
      <span class="mod-subtitulo">Repaso rápido · ${escapar(preguntaPractica.titulo || 'LSC')}</span>
      <h1>Practica tus conocimientos</h1>
      <p>${escapar(preguntaPractica.pregunta)}</p>
      <div class="opciones-practica" role="group" aria-label="Opciones de respuesta">
        ${preguntaPractica.opciones.map((op, i) => `<button class="btn btn-secundario btn-block opcion-practica" data-practica-opcion="${i}">${escapar(op.texto)}</button>`).join('')}
      </div>
      <p id="retro-practica" class="retroalimentacion" role="status" hidden></p>
      <div class="grupo-botones"><button id="otra-practica" class="btn btn-primario" type="button">Otra pregunta</button></div>
    </section>`;
  vista.querySelectorAll('[data-practica-opcion]').forEach(btn => btn.addEventListener('click', () => {
    const elegida = Number(btn.dataset.practicaOpcion);
    const correcta = preguntaPractica.opciones[elegida]?.correcta === true;
    const retro = $("#retro-practica");
    retro.hidden = false;
    retro.className = `retroalimentacion ${correcta ? 'bien' : 'mal'}`;
    retro.textContent = correcta ? (preguntaPractica.retroalimentacionCorrecta || '¡Correcto!') : (preguntaPractica.retroalimentacionIncorrecta || 'No es correcto. Repasa la lección e inténtalo de nuevo.');
    vista.querySelectorAll('[data-practica-opcion]').forEach(b => { b.disabled = true; });
  }));
  $("#otra-practica").addEventListener('click', renderPractica);
}

/* ======================= EVENTOS GLOBALES (delegación) ================== */
function manejarClicGlobal(evento) {
  const destino = evento.target.closest("[data-dashboard],[data-modulo],[data-leccion],[data-continuar],[data-evaluacion],[data-repetir],[data-completar-modulo],[data-ver-proximo]");
  if (!destino) return;

  // Cerrar el menú lateral en móvil al navegar
  cerrarMenuMovil();

  if (destino.dataset.dashboard !== undefined) {
    mostrarVista("dashboard");
  } else if (destino.dataset.modulo !== undefined) {
    estado.moduloActual = destino.dataset.modulo;
    // Reiniciar estado de evaluación al entrar al módulo
    estado.evaluacion = { indice: 0, respuestas: {}, finalizada: false, nota: null };
    mostrarVista("modulo", { idModulo: destino.dataset.modulo });
  } else if (destino.dataset.leccion !== undefined) {
    if (!estado.moduloActual) estado.moduloActual = CURSO.nivelInicial;
    mostrarVista("leccion", { idLeccion: destino.dataset.leccion });
  } else if (destino.dataset.continuar !== undefined) {
    const ult = estado.progreso.ultimaLeccion;
    estado.moduloActual = ult ? ult.modulo : CURSO.nivelInicial;
    mostrarVista("leccion", { idLeccion: destino.dataset.continuar });
  } else if (destino.dataset.evaluacion !== undefined) {
    estado.evaluacion = { indice: 0, respuestas: {}, finalizada: false, nota: null };
    mostrarVista("evaluacion");
  } else if (destino.dataset.repetir !== undefined) {
    estado.evaluacion = { indice: 0, respuestas: {}, finalizada: false, nota: null };
    mostrarVista("evaluacion");
  } else if (destino.dataset.completarModulo !== undefined) {
    completarModulo(destino.dataset.completarModulo);
  } else if (destino.dataset.verProximo !== undefined) {
    estado.moduloActual = destino.dataset.verProximo;
    mostrarVista("modulo", { idModulo: destino.dataset.verProximo });
  }
}

/* Menú lateral en móvil */
function abrirMenuMovil() {
  $("#panel-lateral").classList.add("abierto");
  $("#fondo-menu").hidden = false;
  $("#fondo-menu").classList.add("visible");
  $("#btn-menu").setAttribute("aria-expanded", "true");
}

function cerrarMenuMovil() {
  $("#panel-lateral").classList.remove("abierto");
  $("#fondo-menu").classList.remove("visible");
  $("#fondo-menu").hidden = true;
  $("#btn-menu").setAttribute("aria-expanded", "false");
}

/* ============================== INICIO ================================== */
function iniciarAplicacion() {
  /* Imagen principal de bienvenida */
  $("#imagen-bienvenida").outerHTML = renderMedia(
    URL_IMAGEN_BIENVENIDA,
    "Imagen principal de bienvenida: persona comunicándose en Lengua de Señas Colombiana",
    { claseContenedor: "hero-media", icono: "🤟" }
  ).replace('class="media-contenedor hero-media"', 'class="media-contenedor hero-media" id="imagen-bienvenida"');

  /* Autenticación real contra Flask/MySQL */
  $("#form-login").addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const email = $("#campo-usuario").value.trim();
    const password = $("#campo-clave").value;
    const mensaje = $("#mensaje-error-acceso");
    if (!email || !password) { mensaje.textContent = "Ingresa tu correo y contraseña."; mensaje.hidden = false; return; }
    const boton = evento.currentTarget.querySelector('button[type="submit"]');
    boton.disabled = true; boton.textContent = "Validando..."; mensaje.hidden = true;
    try {
      const response = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No fue posible iniciar sesión.");
      await iniciarSesion(data.user);
    } catch (error) { mensaje.textContent = error.message || "No se pudo conectar con el servidor."; mensaje.hidden = false; $("#campo-clave").value = ""; }
    finally { boton.disabled = false; boton.textContent = "Ingresar al curso"; }
  });

  const formRegistro = $("#form-registro");
  $("#mostrar-registro").addEventListener("click", () => { formRegistro.hidden = false; $("#form-login").hidden = true; $("#mostrar-registro").hidden = true; });
  $("#mostrar-login").addEventListener("click", () => { formRegistro.hidden = true; $("#form-login").hidden = false; $("#mostrar-registro").hidden = false; });
  formRegistro.addEventListener("submit", async (evento) => {
    evento.preventDefault();
    const mensaje = $("#mensaje-registro");
    const boton = formRegistro.querySelector('button[type="submit"]');
    const payload = { names: $("#registro-nombres").value.trim(), surnames: $("#registro-apellidos").value.trim(), email: $("#registro-correo").value.trim(), password: $("#registro-clave").value };
    boton.disabled = true; boton.textContent = "Creando cuenta..."; mensaje.hidden = true;
    try {
      const response = await fetch("/api/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No fue posible crear la cuenta.");
      await iniciarSesion(data.user);
    } catch (error) { mensaje.textContent = error.message || "No se pudo conectar con el servidor."; mensaje.hidden = false; }
    finally { boton.disabled = false; boton.textContent = "Crear mi cuenta"; }
  });

  /* Botones de la barra superior de la app */
  $("#btn-logout").addEventListener("click", cerrarSesion);
  $("#btn-dashboard").addEventListener("click", () => mostrarVista("dashboard"));
  $("#btn-diccionario").addEventListener("click", () => mostrarVista("diccionario"));
  $("#btn-practica").addEventListener("click", () => mostrarVista("practica"));
  $("#btn-menu").addEventListener("click", () => {
    const abierto = $("#panel-lateral").classList.contains("abierto");
    abierto ? cerrarMenuMovil() : abrirMenuMovil();
  });
  $("#fondo-menu").addEventListener("click", cerrarMenuMovil);

  /* Delegación de clics para todos los botones dinámicos */
  document.addEventListener("click", manejarClicGlobal);

  /* Cerrar menú móvil con la tecla Escape */
  document.addEventListener("keydown", (evento) => {
    if (evento.key === "Escape") cerrarMenuMovil();
  });

  /* Restaurar sesión comprobando la cookie segura del servidor */
  restaurarSesion();
}

// Iniciar cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", iniciarAplicacion);
