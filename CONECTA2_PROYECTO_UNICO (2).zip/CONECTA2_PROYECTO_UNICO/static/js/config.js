/* ============================================================================
   CONFIGURACIÓN GENERAL DE LA PLATAFORMA
   ----------------------------------------------------------------------------
   Este archivo concentra TODA la configuración que necesitas cambiar sin
   tocar la estructura del proyecto:

     2. URLs de imágenes y videos (marcadores de reemplazo).
     3. Porcentaje mínimo de aprobación de la evaluación final.
   ============================================================================
*/

/* La autenticación se realiza en Flask y MySQL. No se guardan credenciales en el navegador. */

/* ============================================================================
   2. MARCADORES DE IMÁGENES Y VIDEOS
   ----------------------------------------------------------------------------
   Cada variable de este bloque controla un espacio visual de la plataforma.
   Reemplaza el texto "AQUI_DEBES_PONER_..." por una URL real (https://...).
   Mientras el marcador siga sin reemplazarse, la interfaz mostrará un espacio
   de reemplazo amable ("Imagen pendiente de agregar") sin romper el diseño.

   También puedes usar rutas locales relativas, por ejemplo:
     "./media/imagenes/saludo-hola.jpg"

   Nota: el material lingüístico visual (fotos/videos de señas) debe ser
   validado por personas competentes en LSC antes de su uso definitivo.
   ============================================================================
*/

/* --- Página de bienvenida --- */
// IMAGEN PRINCIPAL DE BIENVENIDA (banner superior de la portada)
const URL_IMAGEN_BIENVENIDA = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN";

/* --- Video o GIF de presentación de la plataforma --- */
// VIDEO O GIF DE DEMOSTRACIÓN DE SEÑAS (se muestra en la lección 1)
const URL_VIDEO_PRESENTACION = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO";

/* --- Imágenes de presentación de los módulos (tarjetas del dashboard) --- */
const URL_IMAGEN_MODULO_BASIC_1 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Portada de Basic 1
const URL_IMAGEN_MODULO_BASIC_2 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Portada de Basic 2 (próximamente)
const URL_IMAGEN_MODULO_BASIC_3 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Portada de Basic 3 (próximamente)
const URL_IMAGEN_MODULO_BASIC_4 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Portada de Basic 4 (próximamente)

/* --- Imágenes de cada lección (tarjetas y pantallas de estudio) --- */
const URL_IMAGEN_LECCION_1 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 1: Introducción a la LSC
const URL_IMAGEN_LECCION_2 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 2: Alfabeto manual
const URL_IMAGEN_LECCION_3 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 3: Saludos y despedidas
const URL_IMAGEN_LECCION_4 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 4: Presentación personal
const URL_IMAGEN_LECCION_5 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 5: Números básicos
const URL_IMAGEN_LECCION_6 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 6: Familia y personas
const URL_IMAGEN_LECCION_7 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 7: Colores
const URL_IMAGEN_LECCION_8 = "AQUI_DEBES_PONER_LA_URL_DE_LA_IMAGEN"; // Lección 8: Expresiones cotidianas

/* --- Videos o GIF demostrativos de las lecciones --- */
const URL_VIDEO_LECCION_1 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Video de presentación de la LSC
const URL_VIDEO_LECCION_2 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración del alfabeto manual
const URL_VIDEO_LECCION_3 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de saludos y despedidas
const URL_VIDEO_LECCION_4 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de presentación personal
const URL_VIDEO_LECCION_5 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de números
const URL_VIDEO_LECCION_6 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de vocabulario de familia
const URL_VIDEO_LECCION_7 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de colores
const URL_VIDEO_LECCION_8 = "AQUI_DEBES_PONER_LA_URL_DEL_VIDEO"; // Demostración de expresiones cotidianas

/* ============================================================================
   3. AJUSTES DEL CURSO
   ============================================================================
*/
// PORCENTAJE MÍNIMO PARA APROBAR LA EVALUACIÓN FINAL (0 a 100)
const PORCENTAJE_APROBACION = 70;

/* Marca de agua informativa: se muestra en las lecciones para recordar que
   el material lingüístico visual aún debe ser revisado por expertos en LSC. */
const NOTA_VALIDACION_LSC =
  "Nota: las descripciones de esta lección son material preliminar. " +
  "Las configuraciones de manos, movimientos, orientaciones y expresiones faciales " +
  "deben validarse con personas competentes en Lengua de Señas Colombiana.";
