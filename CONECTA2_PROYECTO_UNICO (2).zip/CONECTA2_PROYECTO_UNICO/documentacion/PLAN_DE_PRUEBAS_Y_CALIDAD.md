# CONECTA2 | Plan inicial de pruebas y calidad

Este plan traduce a verificaciones prácticas el alcance y los requisitos funcionales RS-01 a RS-12 de la propuesta de Calidad de Software de CONECTA2. La ejecución de estas pruebas debe registrarse con fecha, responsable, resultado y evidencia (captura o salida de consola).

## Matriz de requisitos funcionales

| Código | Requisito documentado | Prueba propuesta | Resultado esperado |
|---|---|---|---|
| RS-01 | Registrar usuarios | Registrar una cuenta nueva con datos válidos y luego intentar repetir el correo | La primera cuenta se crea; el correo duplicado se rechaza |
| RS-02 | Iniciar y cerrar sesión | Iniciar sesión con credenciales correctas, cerrar sesión y consultar `/api/session` | La sesión se abre y se cierra correctamente |
| RS-03 | Mostrar categorías | Abrir el diccionario y consultar `/api/dictionary` | Se muestran palabras con su categoría, procedentes de MySQL |
| RS-04 | Acceder a lecciones | Abrir el catálogo y consultar `/api/lessons` | Se presentan las lecciones disponibles |
| RS-05 | Presentar contenido escrito y audiovisual | Abrir una lección y verificar texto, espacio multimedia y recurso configurado | El contenido textual se muestra y el medio funciona cuando su URL es válida |
| RS-06 | Realizar actividades interactivas | Completar un ejercicio de opción o relación | La interfaz valida la respuesta y muestra retroalimentación |
| RS-07 | Almacenar resultados de actividades | Completar una evaluación con sesión iniciada y revisar la tabla auxiliar | El resultado se registra en MySQL |
| RS-08 | Realizar evaluaciones | Completar la evaluación de un módulo | Se calcula y presenta el resultado |
| RS-09 | Asignar puntuación | Responder correctamente y luego repetir con errores | La puntuación refleja el desempeño según las reglas de la actividad |
| RS-10 | Registrar progreso | Completar una lección con sesión iniciada y recargar la página | El progreso sincronizado se recupera desde MySQL |
| RS-11 | Mostrar nivel alcanzado | Completar actividades y revisar el panel de progreso | El nivel/puntuación se actualiza según la lógica implementada |
| RS-12 | Administración de contenido | Abrir `/api/admin/stats` con cuenta autorizada y con cuenta de estudiante | Administrador obtiene estadísticas; estudiante recibe acceso denegado |

## Criterios de calidad iniciales

| Área | Criterio verificable | Método |
|---|---|---|
| Adecuación funcional | Los flujos principales de registro, acceso, lecciones, evaluación y progreso pueden completarse | Pruebas funcionales de la matriz anterior |
| Usabilidad | Navegación y formularios se entienden sin instrucciones externas; los errores se comunican en español | Prueba exploratoria con usuarios y lista de observación |
| Accesibilidad | Foco visible con teclado, textos alternativos para imágenes, etiquetas de formularios y contraste legible | Recorrido solo con teclado y revisión visual |
| Fiabilidad | La aplicación muestra un error controlado cuando MySQL no está disponible, sin mostrar credenciales | Detener temporalmente MySQL y consultar `/api/health` |
| Seguridad básica | Contraseñas almacenadas con hash; acceso a estadísticas limitado por rol; secretos fuera del código público | Inspección del código y pruebas de permisos |
| Mantenibilidad | Configuración separada del código, estructura de archivos consistente y guía de instalación disponible | Revisión de estructura y README |
| Compatibilidad | La interfaz se adapta a tamaños de escritorio y móvil en navegadores modernos | Prueba responsive en DevTools y navegador |

## Registro de ejecución

| Fecha | Prueba | Resultado (Aprobada/Fallida/No ejecutada) | Evidencia / observación |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## Límites conocidos antes de presentar

- La aplicación debe probarse en la instalación real de MySQL de la máquina donde se presentará.
- Los videos e imágenes de señas requieren URLs autorizadas y validación lingüística; los marcadores no cuentan como evidencia de contenido audiovisual finalizado.
- La matriz es un plan inicial: no implica que todas las pruebas ya hayan sido ejecutadas ni que el producto esté certificado conforme a ISO/IEC 25010:2023.
- El MVP no incluye reconocimiento automático de señas, traducción automática ni interpretación por cámara; estos elementos están fuera del alcance inicial descrito en la propuesta.
