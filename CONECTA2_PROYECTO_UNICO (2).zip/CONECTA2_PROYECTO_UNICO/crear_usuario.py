"""Crea una cuenta de estudiante en la base de datos CONECTA2."""
import getpass
from werkzeug.security import generate_password_hash
from db import get_db_connection


def main():
    nombres = input("Nombres: ").strip()
    apellidos = input("Apellidos: ").strip()
    correo = input("Correo electrónico: ").strip().lower()
    if not nombres or not apellidos or "@" not in correo:
        raise ValueError("Ingresa nombres, apellidos y un correo válido.")
    clave = getpass.getpass("Contraseña (mínimo 8 caracteres): ")
    if len(clave) < 8:
        raise ValueError("La contraseña debe tener al menos 8 caracteres.")

    con = get_db_connection()
    try:
        with con.cursor(dictionary=True) as cur:
            cur.execute("SELECT id_usuario FROM usuario WHERE LOWER(correo)=%s LIMIT 1", (correo,))
            if cur.fetchone():
                raise ValueError("Ya existe una cuenta con ese correo.")
            cur.execute("SELECT id_rol FROM rol WHERE LOWER(nombre)='estudiante' LIMIT 1")
            rol = cur.fetchone()
            if not rol:
                raise RuntimeError("No existe el rol Estudiante. Importa primero lsc_conecta2.sql.")
            cur.execute(
                "INSERT INTO usuario (id_rol,nombres,apellidos,correo,contrasena,estado) VALUES (%s,%s,%s,%s,%s,'Activo')",
                (rol['id_rol'], nombres, apellidos, correo, generate_password_hash(clave)),
            )
        con.commit()
        print("Cuenta creada correctamente. Ya puedes iniciar sesión en CONECTA2.")
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


if __name__ == "__main__":
    main()
