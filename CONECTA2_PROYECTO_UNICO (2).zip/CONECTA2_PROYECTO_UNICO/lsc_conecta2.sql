CREATE DATABASE  IF NOT EXISTS `lsc_conecta2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `lsc_conecta2`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lsc_conecta2
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Saludos','Expresiones utilizadas para saludar'),(2,'Familia','Personas y relaciones familiares'),(3,'Colores','Vocabulario relacionado con colores'),(4,'Números','Números y cantidades'),(5,'Animales','Nombres de animales'),(6,'Alimentos','Comidas y bebidas'),(7,'Emociones','Estados emocionales'),(8,'Lugares','Lugares y espacios comunes');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curso`
--

DROP TABLE IF EXISTS `curso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `curso` (
  `id_curso` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` text,
  `nivel` enum('Basico','Intermedio','Avanzado') NOT NULL,
  `duracion_horas` decimal(5,2) DEFAULT NULL,
  `estado` enum('Activo','Inactivo') DEFAULT 'Activo',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_curso`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curso`
--

LOCK TABLES `curso` WRITE;
/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
INSERT INTO `curso` VALUES (1,'Introducción a la LSC','Curso introductorio para aprender conceptos básicos de Lengua de Señas Colombiana.','Basico',12.00,'Activo','2026-10-01 21:29:44'),(2,'LSC Nivel Intermedio','Curso orientado al fortalecimiento del vocabulario y la comunicación.','Intermedio',20.00,'Activo','2026-10-01 21:29:44'),(3,'Comunicación en LSC','Curso enfocado en situaciones cotidianas de comunicación.','Avanzado',25.00,'Activo','2026-10-01 21:29:44');
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluacion`
--

DROP TABLE IF EXISTS `evaluacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluacion` (
  `id_evaluacion` int NOT NULL AUTO_INCREMENT,
  `id_leccion` int NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `descripcion` text,
  `puntaje_maximo` decimal(5,2) DEFAULT '100.00',
  PRIMARY KEY (`id_evaluacion`),
  KEY `id_leccion` (`id_leccion`),
  CONSTRAINT `evaluacion_ibfk_1` FOREIGN KEY (`id_leccion`) REFERENCES `leccion` (`id_leccion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluacion`
--

LOCK TABLES `evaluacion` WRITE;
/*!40000 ALTER TABLE `evaluacion` DISABLE KEYS */;
INSERT INTO `evaluacion` VALUES (1,1,'Evaluación de saludos','Evaluación sobre las señas aprendidas en la lección.',100.00);
/*!40000 ALTER TABLE `evaluacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leccion`
--

DROP TABLE IF EXISTS `leccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leccion` (
  `id_leccion` int NOT NULL AUTO_INCREMENT,
  `id_modulo` int NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `contenido` text,
  `orden` int NOT NULL,
  `duracion_minutos` int DEFAULT NULL,
  PRIMARY KEY (`id_leccion`),
  KEY `id_modulo` (`id_modulo`),
  CONSTRAINT `leccion_ibfk_1` FOREIGN KEY (`id_modulo`) REFERENCES `modulo` (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leccion`
--

LOCK TABLES `leccion` WRITE;
/*!40000 ALTER TABLE `leccion` DISABLE KEYS */;
INSERT INTO `leccion` VALUES (1,1,'Formas de saludo','Aprendizaje de vocabulario básico para saludar.',1,15),(2,1,'Presentaciones personales','Expresiones utilizadas para presentarse.',2,20),(3,2,'Mi familia','Vocabulario relacionado con familiares.',1,20);
/*!40000 ALTER TABLE `leccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modulo`
--

DROP TABLE IF EXISTS `modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modulo` (
  `id_modulo` int NOT NULL AUTO_INCREMENT,
  `id_curso` int NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `descripcion` text,
  `orden` int NOT NULL,
  PRIMARY KEY (`id_modulo`),
  KEY `id_curso` (`id_curso`),
  CONSTRAINT `modulo_ibfk_1` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modulo`
--

LOCK TABLES `modulo` WRITE;
/*!40000 ALTER TABLE `modulo` DISABLE KEYS */;
INSERT INTO `modulo` VALUES (1,1,'Saludos y presentaciones','Vocabulario básico para iniciar una conversación.',1),(2,1,'Familia','Señas relacionadas con miembros de la familia.',2),(3,1,'Colores','Aprendizaje de los principales colores.',3);
/*!40000 ALTER TABLE `modulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregunta`
--

DROP TABLE IF EXISTS `pregunta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pregunta` (
  `id_pregunta` int NOT NULL AUTO_INCREMENT,
  `id_evaluacion` int NOT NULL,
  `enunciado` text NOT NULL,
  `tipo` enum('SeleccionMultiple','VerdaderoFalso') NOT NULL,
  `puntaje` decimal(5,2) DEFAULT '10.00',
  PRIMARY KEY (`id_pregunta`),
  KEY `id_evaluacion` (`id_evaluacion`),
  CONSTRAINT `pregunta_ibfk_1` FOREIGN KEY (`id_evaluacion`) REFERENCES `evaluacion` (`id_evaluacion`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregunta`
--

LOCK TABLES `pregunta` WRITE;
/*!40000 ALTER TABLE `pregunta` DISABLE KEYS */;
INSERT INTO `pregunta` VALUES (1,1,'¿Cuál de las siguientes señas corresponde a un saludo?','SeleccionMultiple',10.00),(2,1,'La seña GRACIAS se utiliza para expresar agradecimiento.','VerdaderoFalso',10.00);
/*!40000 ALTER TABLE `pregunta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progreso`
--

DROP TABLE IF EXISTS `progreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progreso` (
  `id_progreso` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_curso` int NOT NULL,
  `porcentaje` decimal(5,2) DEFAULT '0.00',
  `lecciones_completadas` int DEFAULT '0',
  `ultima_actividad` datetime DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('No iniciado','En progreso','Completado') DEFAULT 'No iniciado',
  PRIMARY KEY (`id_progreso`),
  UNIQUE KEY `id_usuario` (`id_usuario`,`id_curso`),
  KEY `id_curso` (`id_curso`),
  CONSTRAINT `progreso_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `progreso_ibfk_2` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progreso`
--

LOCK TABLES `progreso` WRITE;
/*!40000 ALTER TABLE `progreso` DISABLE KEYS */;
INSERT INTO `progreso` VALUES (1,2,1,66.67,2,'2026-10-01 21:31:59','En progreso'),(2,3,1,100.00,3,'2026-10-01 21:31:59','Completado');
/*!40000 ALTER TABLE `progreso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuesta`
--

DROP TABLE IF EXISTS `respuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respuesta` (
  `id_respuesta` int NOT NULL AUTO_INCREMENT,
  `id_pregunta` int NOT NULL,
  `texto_respuesta` varchar(300) NOT NULL,
  `es_correcta` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id_respuesta`),
  KEY `id_pregunta` (`id_pregunta`),
  CONSTRAINT `respuesta_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuesta`
--

LOCK TABLES `respuesta` WRITE;
/*!40000 ALTER TABLE `respuesta` DISABLE KEYS */;
INSERT INTO `respuesta` VALUES (1,1,'HOLA',1),(2,1,'ROJO',0),(3,1,'MADRE',0),(4,1,'ANIMAL',0),(5,2,'Verdadero',1),(6,2,'Falso',0);
/*!40000 ALTER TABLE `respuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (1,'Administrador','Gestiona usuarios, cursos y contenido'),(2,'Estudiante','Accede a cursos y actividades'),(3,'Docente','Gestiona contenido educativo y evaluaciones');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sena`
--

DROP TABLE IF EXISTS `sena`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sena` (
  `id_sena` int NOT NULL AUTO_INCREMENT,
  `id_categoria` int NOT NULL,
  `palabra` varchar(100) NOT NULL,
  `definicion` varchar(300) DEFAULT NULL,
  `descripcion_movimiento` text,
  `ejemplo_uso` varchar(300) DEFAULT NULL,
  `nivel` enum('Basico','Intermedio','Avanzado') DEFAULT 'Basico',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_sena`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `sena_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sena`
--

LOCK TABLES `sena` WRITE;
/*!40000 ALTER TABLE `sena` DISABLE KEYS */;
INSERT INTO `sena` VALUES (1,1,'HOLA','Expresión utilizada para saludar a otra persona','Se realiza el movimiento correspondiente a la seña de saludo.','Hola, ¿cómo estás?','Basico','2026-10-01 21:29:19'),(2,1,'GRACIAS','Expresión utilizada para agradecer','Movimiento utilizado convencionalmente para expresar agradecimiento.','Gracias por ayudarme.','Basico','2026-10-01 21:29:19'),(3,2,'MADRE','Persona que tiene hijos','Seña correspondiente al concepto de madre.','Mi madre vive en Bogotá.','Basico','2026-10-01 21:29:19'),(4,2,'PADRE','Persona que tiene hijos','Seña correspondiente al concepto de padre.','Mi padre trabaja en Bogotá.','Basico','2026-10-01 21:29:19'),(5,3,'ROJO','Color asociado con diferentes objetos y elementos.','Seña correspondiente al concepto del color rojo.','El carro es rojo.','Basico','2026-10-01 21:29:19');
/*!40000 ALTER TABLE `sena` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `id_rol` int NOT NULL,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `ciudad` varchar(80) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  `estado` enum('Activo','Inactivo','Bloqueado') DEFAULT 'Activo',
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo` (`correo`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,1,'Laura','Gómez','laura.gomez@lscaprende.com','HashDemo001','1995-04-12','Bogotá','2026-10-01 21:28:32','Activo'),(2,2,'Andrés','Martínez','andres.martinez@gmail.com','HashDemo002','2002-08-21','Medellín','2026-10-01 21:28:32','Activo'),(3,2,'Valentina','Rodríguez','valentina.rodriguez@gmail.com','HashDemo003','2001-02-15','Cali','2026-10-01 21:28:32','Activo'),(4,3,'Camilo','Torres','camilo.torres@lscaprende.com','HashDemo004','1990-11-09','Bogotá','2026-10-01 21:28:32','Activo');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `id_video` int NOT NULL AUTO_INCREMENT,
  `id_leccion` int NOT NULL,
  `id_sena` int DEFAULT NULL,
  `titulo` varchar(150) NOT NULL,
  `url_video` varchar(500) NOT NULL,
  `duracion_segundos` int DEFAULT NULL,
  `descripcion` text,
  PRIMARY KEY (`id_video`),
  KEY `id_leccion` (`id_leccion`),
  KEY `id_sena` (`id_sena`),
  CONSTRAINT `video_ibfk_1` FOREIGN KEY (`id_leccion`) REFERENCES `leccion` (`id_leccion`),
  CONSTRAINT `video_ibfk_2` FOREIGN KEY (`id_sena`) REFERENCES `sena` (`id_sena`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES (1,1,1,'Seña de HOLA','https://ejemplo.com/videos/hola.mp4',25,'Demostración visual de la seña HOLA'),(2,1,2,'Seña de GRACIAS','https://ejemplo.com/videos/gracias.mp4',30,'Demostración visual de la seña GRACIAS');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'lsc_conecta2'
--

--
-- Dumping routines for database 'lsc_conecta2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-01 22:22:03
