USE conecta2;

DELIMITER //

CREATE PROCEDURE migrar_racha_conecta2()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'usuarios'
          AND COLUMN_NAME = 'racha'
    ) THEN
        ALTER TABLE usuarios
            ADD COLUMN racha INT UNSIGNED NOT NULL DEFAULT 0;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'usuarios'
          AND COLUMN_NAME = 'ultima_racha'
    ) THEN
        ALTER TABLE usuarios
            ADD COLUMN ultima_racha DATE NULL;
    END IF;
END//

DELIMITER ;

CALL migrar_racha_conecta2();
DROP PROCEDURE migrar_racha_conecta2;
